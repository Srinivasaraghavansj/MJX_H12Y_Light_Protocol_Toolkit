# Changelog

## 1.0.0 - 2026-07-17

- Added ATmega328P Nano CH3 learner with D4-to-D7 passthrough.
- Added ten-state automatic capture matrix and EEPROM capture log.
- Added Timer1-driven D7 command emulator.
- Added natural driving commands and combined direction commands.
- Added manual and tracked lighting-mode commands.
- Documented the validated three-field MJX protocol and capture data.
- Confirmed that startup sends no automatic CH3 press and retains the stock
  lighting board's default ON state.

