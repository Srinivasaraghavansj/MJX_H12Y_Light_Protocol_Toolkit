# MJX H12Y lighting protocol

## Summary

The stock receiver output is not normal servo PWM and is not a conventional
PPM-sum stream. It is a repeating active-HIGH pulse-field frame containing
three independently varying fields.

```text
LOW sync
  -> HIGH field 0: CH3 command
  -> LOW separator
  -> HIGH field 1: throttle
  -> LOW separator
  -> HIGH field 2: steering
  -> LOW sync
  -> repeat
```

## Validated frame values

```text
polarity       = ACTIVE_HIGH
channel_count  = 3
sync_low       = 12154 us
separator_low  = 1027 us
field_order    = CH3, throttle, steering
```

### Field 0: CH3 command

| State | Width |
|---|---:|
| Released | 6104 µs |
| Pressed | 5110 µs |

CH3 is a momentary command, not a three-position steady mode field. With no
press at power-up, the stock board keeps its normal lights ON. Each completed
press advances the board's stored mode:

```text
ON -> HAZARD -> OFF -> ON
```

The emulator uses a 350 ms pressed interval followed by the released value.

### Field 1: throttle

| State | Width |
|---|---:|
| Reverse | 2063 µs |
| Neutral | 3027 µs |
| Forward | 4071 µs |

The lighting board derives reverse and brake behaviors from this field. The
brake behavior can depend on the transition history, such as forward followed
by neutral.

### Field 2: steering

| State | Width |
|---|---:|
| Left | 2036 µs |
| Center | 3026 µs |
| Right | 4069 µs |

The lighting board uses this field for left and right indicator behavior.

## Captured variation

Individual captures varied by tens of microseconds. Examples from the validated
matrix include:

- CH3 released: approximately 6078–6132 µs
- CH3 pressed: approximately 5110 µs
- throttle reverse: approximately 2034–2063 µs
- throttle neutral: approximately 3027–3095 µs
- throttle forward: approximately 4063–4078 µs
- steering left: approximately 2032–2036 µs
- steering center: approximately 3026–3092 µs
- steering right: approximately 4061–4073 µs

The emulator uses the values printed by the successful learner calibration.

## Timer1 encoder

The emulator configures the ATmega328P Timer1 in CTC mode with a prescaler of
8. At 16 MHz this gives two timer ticks per microsecond. The interrupt handler
changes D7 and schedules each sync, field, and separator duration without using
blocking delays.

Pending command values are copied into the active frame only at the sync-to-
field-0 boundary. Combined commands therefore change atomically between frames.

## Passthrough method

The learner enables the D4 pin-change interrupt. At every D4 transition, the
interrupt handler updates D7 using direct AVR port access before recording the
edge timing. This keeps passthrough delay small and allows the stock lighting
board to provide immediate visual feedback while learning.

