# Testing guide

## Reader and passthrough test

1. Wire receiver CH3 to D4 and Nano D7 to the lighting-board input.
2. Upload `H12Y_CH3_Learner`.
3. Open Serial Monitor at 115200 baud with Newline selected.
4. Confirm this startup message appears:

```text
MJX H12Y CH3 protocol learner + D7 passthrough ready.
D4 receiver input is being mirrored continuously to D7.
```

5. Move steering and throttle and operate CH3.
6. Confirm the stock lighting board behaves as it did when connected directly
   to the receiver.

Use `sample` to decode the current state or `raw` to print edge timings.

## New calibration matrix

Type:

```text
matrix
```

The learner clears its previous log and automatically requests ten states:

1. Center, neutral, CH3 released
2. Left, forward, CH3 released
3. Center, forward, CH3 released
4. Right, forward, CH3 released
5. Left, neutral, CH3 released
6. Right, neutral, CH3 released
7. Left, reverse, CH3 released
8. Center, reverse, CH3 released
9. Right, reverse, CH3 released
10. Center, neutral, CH3 held pressed

Each prompt provides five seconds to set the controls, then captures multiple
samples for two seconds. Successful data is stored in EEPROM automatically.

If power or Serial Monitor is interrupted, upload the same sketch and type:

```text
resume
```

`resume` works only when the capture rows remain in the same Nano's EEPROM.

## Emulator test

1. Upload `H12Y_D7_Command_Emulator`.
2. Keep the lighting board connected to D7.
3. D4 may remain connected to the receiver but is ignored by this sketch.
4. Power-cycle the Nano and lighting board together.
5. Confirm the normal lights remain ON without any automatic CH3 press.
6. Open Serial Monitor at 115200 baud with Newline selected.

Try:

```text
forward left
straight
neutral
backward right
press
press
press
```

Expected mode sequence from startup:

```text
ON
HAZARD
OFF
ON
```

## Complete automatic visual test

Ensure the vehicle is safely supported, then type:

```text
all
```

Watch the Serial labels and record the corresponding stock-light behavior.
Type `stop` at any time to return to centered steering, neutral throttle, and
CH3 released.

## Raw exploration

The emulator accepts direct field widths:

```text
raw 6104 3027 3026
```

The order is CH3, throttle, steering. Values outside 500–12000 µs are rejected.
Raw mode is intended for controlled protocol research; normal commands are
safer for routine testing.

## Troubleshooting

### No response from the lighting board

- Confirm common ground.
- Confirm D7 reaches the lighting-board signal input.
- Confirm the receiver output is not also driving that same input.
- Verify the board accepts Nano 5 V logic.
- Confirm the classic Nano/ATmega328P board target was selected.

### Reader reports zero samples

- Confirm the signal is connected to D4, not another Nano pin.
- Confirm receiver and Nano grounds are common.
- Use `raw` and verify that D4 produces transitions.
- Check whether an external level shifter inverted or suppressed the signal.

### Mode command is one position out

The lighting board stores mode internally. If it reset independently or missed
a gesture, the emulator's tracked mode may differ. Power-cycle the Nano and
lighting board together to restore the known default ON state.

