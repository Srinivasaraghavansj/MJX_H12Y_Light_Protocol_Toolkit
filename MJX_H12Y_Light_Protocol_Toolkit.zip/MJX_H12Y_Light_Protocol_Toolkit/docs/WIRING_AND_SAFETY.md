# Wiring and safety

## Required connections

```text
Stock receiver CH3 signal ----------> Nano D4
Nano D7 ----------------------------> Lighting-board signal input
Receiver ground --------------------> Nano GND
Lighting-board ground --------------> Nano GND
```

## Signal ownership

Disconnect the receiver's CH3 signal from the lighting-board signal input. The
receiver output goes to D4, and D7 becomes the lighting board's only signal
driver.

Do not connect the receiver output and Nano D7 together. Both may be push-pull
outputs; tying them together can cause excessive current and damage.

## Power

- Use a regulated supply appropriate for the Nano and installed electronics.
- Do not connect an unknown receiver positive lead directly to Nano VIN.
- Connect all grounds before testing signals.
- Avoid powering the Nano simultaneously from incompatible 5 V sources.
- For final installation, powering/resetting the Nano and lighting board
  together helps keep remembered lighting-mode state synchronized.

## Logic voltage

A classic Nano normally outputs approximately 5 V logic. Measure or confirm the
lighting-board input voltage before connecting D7. If the board expects 3.3 V
logic, use a proper unidirectional level shifter or suitable resistor/transistor
interface that preserves the waveform polarity.

The learner constants assume that the D4 input and D7 output circuits do not
invert the waveform. If an inverting conditioner is used, review
`SIGNAL_CONDITIONER_INVERTS` and `PASSTHROUGH_INVERTS_INPUT` in the learner and
the output polarity in the emulator.

## Safe first test

1. Support the vehicle so its wheels cannot unexpectedly drive the car.
2. Verify grounds and signal ownership with power removed.
3. Upload the learner before connecting the lighting-board signal if desired.
4. Power the Nano, receiver, and lighting board.
5. Confirm the learner reports D4-to-D7 passthrough.
6. Test centered steering and neutral throttle first.
7. Test throttle commands only when the vehicle is safely restrained.

