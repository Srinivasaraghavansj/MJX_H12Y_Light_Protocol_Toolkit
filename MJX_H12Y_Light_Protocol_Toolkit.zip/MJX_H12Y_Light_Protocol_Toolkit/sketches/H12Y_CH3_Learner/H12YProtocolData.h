#ifndef H12Y_PROTOCOL_DATA_H
#define H12Y_PROTOCOL_DATA_H

#include <Arduino.h>
#include <EEPROM.h>
#include <stddef.h>

namespace H12YProtocol {

constexpr uint32_t CALIBRATION_MAGIC = 0x48313259UL;  // "H12Y"
constexpr uint8_t CALIBRATION_VERSION = 2;
constexpr int EEPROM_CALIBRATION_ADDRESS = 0;
constexpr uint8_t MAX_PPM_CHANNELS = 8;

constexpr uint8_t FLAG_PPM_ACTIVE_HIGH = 0x01;

enum SignalProtocol : uint8_t {
  PROTOCOL_PPM_SUM = 1,
  PROTOCOL_MJX_PULSE_FIELDS = 2,
};

enum AxisPoint : uint8_t {
  AXIS_LOW = 0,
  AXIS_CENTER = 1,
  AXIS_HIGH = 2,
};

enum LightMode : uint8_t {
  MODE_LINKAGE = 0,
  MODE_HAZARD = 1,
  MODE_OFF = 2,
};

// This exact structure is shared by both sketches. The Nano learner and Pro
// Micro bridge have separate EEPROM, so transfer the printed calibration before
// running the bridge.
struct __attribute__((packed)) BridgeCalibration {
  uint32_t magic;
  uint8_t version;
  uint8_t protocol;
  uint8_t flags;
  uint8_t channelCount;
  uint8_t steeringIndex;
  uint8_t throttleIndex;
  uint8_t modeIndex;
  uint16_t frameUs;
  uint16_t pulseUs;
  uint16_t defaultValues[MAX_PPM_CHANNELS];
  uint16_t steeringUs[3];       // left, center, right
  uint16_t throttleUs[3];       // reverse, neutral, forward
  uint16_t modeUs[3];           // linkage, hazard, off
  uint8_t reserved[8];
  uint16_t crc;
};

inline uint16_t crc16Update(uint16_t crc, uint8_t data) {
  crc ^= static_cast<uint16_t>(data) << 8;
  for (uint8_t bit = 0; bit < 8; ++bit) {
    crc = (crc & 0x8000U) ? static_cast<uint16_t>((crc << 1) ^ 0x1021U)
                          : static_cast<uint16_t>(crc << 1);
  }
  return crc;
}

inline uint16_t calibrationCrc(const BridgeCalibration &calibration) {
  const uint8_t *bytes = reinterpret_cast<const uint8_t *>(&calibration);
  uint16_t crc = 0xFFFFU;
  for (size_t i = 0; i < offsetof(BridgeCalibration, crc); ++i) {
    crc = crc16Update(crc, bytes[i]);
  }
  return crc;
}

inline bool valueLooksValid(uint8_t protocol, uint16_t value) {
  if (protocol == PROTOCOL_PPM_SUM) {
    return value >= 700U && value <= 2300U;
  }
  if (protocol == PROTOCOL_MJX_PULSE_FIELDS) {
    return value >= 500U && value <= 12000U;
  }
  return false;
}

inline bool calibrationIsValid(const BridgeCalibration &calibration) {
  if (calibration.magic != CALIBRATION_MAGIC ||
      calibration.version != CALIBRATION_VERSION ||
      (calibration.protocol != PROTOCOL_PPM_SUM &&
       calibration.protocol != PROTOCOL_MJX_PULSE_FIELDS) ||
      calibration.channelCount == 0 ||
      calibration.channelCount > MAX_PPM_CHANNELS ||
      calibration.steeringIndex >= calibration.channelCount ||
      calibration.throttleIndex >= calibration.channelCount ||
      calibration.modeIndex >= calibration.channelCount ||
      calibration.steeringIndex == calibration.throttleIndex ||
      calibration.steeringIndex == calibration.modeIndex ||
      calibration.throttleIndex == calibration.modeIndex ||
      calibration.crc != calibrationCrc(calibration)) {
    return false;
  }

  if (calibration.protocol == PROTOCOL_PPM_SUM) {
    if (calibration.frameUs < 8000U || calibration.frameUs > 40000U ||
        calibration.pulseUs < 50U || calibration.pulseUs > 1000U) {
      return false;
    }
  } else {
    // For MJX pulse fields, frameUs stores the long sync gap and pulseUs stores
    // the short inter-field gap.
    if (calibration.frameUs < 3000U || calibration.frameUs > 30000U ||
        calibration.pulseUs < 100U || calibration.pulseUs > 5000U) {
      return false;
    }
  }

  for (uint8_t i = 0; i < calibration.channelCount; ++i) {
    if (!valueLooksValid(calibration.protocol,
                         calibration.defaultValues[i])) {
      return false;
    }
  }
  for (uint8_t i = 0; i < 3; ++i) {
    if (!valueLooksValid(calibration.protocol, calibration.steeringUs[i]) ||
        !valueLooksValid(calibration.protocol, calibration.throttleUs[i]) ||
        !valueLooksValid(calibration.protocol, calibration.modeUs[i])) {
      return false;
    }
  }
  return true;
}

inline bool loadCalibration(BridgeCalibration &calibration) {
  EEPROM.get(EEPROM_CALIBRATION_ADDRESS, calibration);
  return calibrationIsValid(calibration);
}

inline void saveCalibration(BridgeCalibration &calibration) {
  calibration.magic = CALIBRATION_MAGIC;
  calibration.version = CALIBRATION_VERSION;
  calibration.crc = calibrationCrc(calibration);
  EEPROM.put(EEPROM_CALIBRATION_ADDRESS, calibration);
}

inline void eraseCalibration() {
  EEPROM.update(EEPROM_CALIBRATION_ADDRESS, 0xFF);
}

}  // namespace H12YProtocol

#endif
