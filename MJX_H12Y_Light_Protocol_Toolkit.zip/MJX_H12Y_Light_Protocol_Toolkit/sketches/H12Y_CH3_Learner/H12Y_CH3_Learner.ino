/*
  MJX H12Y stock CH3 protocol learner for classic Arduino Nano (ATmega328P)

  Purpose:
    1. Capture the signal sent by the stock R4B receiver's CH3 output.
    2. Detect a PPM-sum style composite stream without assuming channel order.
    3. Learn steering, throttle and momentary CH3-command fields.
    4. Save the result to EEPROM for H12Y_Light_Bridge.ino.

  Wiring for a 5 V Nano after verifying signal voltage:
    R4B CH3 signal -> suitable level shifter/protection -> Nano D4
    Nano D7       -> stock lighting-board signal input
    R4B ground     --------------------------> Nano GND
    Lighting board ground -------------------> Nano GND

  Do not connect the receiver's positive wire to VIN. Power the Nano from
  a known regulated supply. If CH3 exceeds the Nano logic voltage, add a
  proper level shifter before D4.
*/

#include "H12YProtocolData.h"
#include <avr/interrupt.h>

#if !defined(__AVR_ATmega328P__)
#error "This learner now targets a classic ATmega328P Arduino Nano."
#endif

using namespace H12YProtocol;

namespace {

constexpr uint8_t SIGNAL_PIN = 4;       // Nano D4 = PD4 = PCINT20.
constexpr uint8_t PASSTHROUGH_PIN = 7;  // Nano D7 = PD7.
// D7 normally reproduces the electrical level seen on D4. Change this only
// when an inverting input/output conditioning circuit requires it.
constexpr bool PASSTHROUGH_INVERTS_INPUT = false;
// Set true only if the circuit between CH3 and D4 inverts the waveform, such
// as a single-NPN level shifter. EEPROM will still store physical CH3 polarity.
constexpr bool SIGNAL_CONDITIONER_INVERTS = false;
constexpr uint16_t CAPTURE_TIME_MS = 220;
// Sized for the Nano's 2 KB SRAM. A three-channel 50 Hz PPM stream uses far
// fewer entries than these limits during one 220 ms sub-capture.
constexpr uint16_t MAX_EDGES = 160;
constexpr uint8_t MAX_PULSE_STARTS = 56;
constexpr uint8_t MAX_CAPTURED_FRAMES = 6;
constexpr uint16_t NARROW_MIN_US = 80;
constexpr uint16_t NARROW_MAX_US = 600;
constexpr uint16_t SYNC_MIN_US = 3000;
constexpr uint16_t MJX_SYNC_MIN_US = 8000;
constexpr uint16_t MJX_FIELD_MIN_US = 500;
constexpr uint16_t MJX_FIELD_MAX_US = 12000;
constexpr uint16_t MJX_SEPARATOR_MIN_US = 100;
constexpr uint16_t MJX_SEPARATOR_MAX_US = 5000;

volatile bool gCapturing = false;
volatile uint16_t gEdgeCount = 0;
volatile uint32_t gLastEdgeUs = 0;
volatile uint16_t gDurationsUs[MAX_EDGES];
volatile uint8_t gLevelAfterBits[(MAX_EDGES + 7) / 8];

uint32_t gPulseStartsUs[MAX_PULSE_STARTS];
uint16_t gFrameValues[MAX_CAPTURED_FRAMES][MAX_PPM_CHANNELS];

struct PpmSample {
  bool valid;
  uint8_t protocol;
  bool activeHigh;
  uint8_t channelCount;
  uint16_t frameUs;
  uint16_t pulseUs;
  uint16_t values[MAX_PPM_CHANNELS];
};

enum SnapshotId : uint8_t {
  SNAP_BASE = 0,
  SNAP_LEFT,
  SNAP_RIGHT,
  SNAP_FORWARD,
  SNAP_REVERSE,
  SNAP_HAZARD,
  SNAP_OFF,
  SNAP_COUNT,
};

const char *const SNAPSHOT_NAMES[SNAP_COUNT] = {
    "base", "left", "right", "forward", "reverse", "button_pressed",
    "idle_copy"};

PpmSample gSnapshots[SNAP_COUNT] = {};
char gCommand[24];
uint8_t gCommandLength = 0;

// Capture log starts after the shared bridge calibration record. The ATmega328P
// has 1024 bytes of EEPROM; the selected record count fits from this address.
constexpr int EEPROM_LOG_ADDRESS = 64;
constexpr uint32_t CAPTURE_LOG_MAGIC = 0x484C4F47UL;  // "HLOG"
constexpr uint8_t CAPTURE_LOG_VERSION = 2;
constexpr uint8_t MAX_LOG_RECORDS = 32;
constexpr uint8_t LOG_KIND_MATRIX = 1;
constexpr uint8_t LOG_KIND_AUTO = 2;
constexpr uint8_t STATE_UNKNOWN = 0xFF;
constexpr uint16_t STABLE_VALUE_TOLERANCE_US = 80;
constexpr bool AUTO_DUMP_AFTER_APPEND = true;

struct __attribute__((packed)) CaptureLogHeader {
  uint32_t magic;
  uint8_t version;
  uint8_t count;
  uint16_t reserved;
};

struct __attribute__((packed)) CaptureLogRecord {
  uint8_t kind;
  uint8_t protocol;
  uint8_t steeringState;
  uint8_t throttleState;
  uint8_t modeState;
  uint8_t flags;
  uint8_t channelCount;
  uint16_t frameUs;
  uint16_t pulseUs;
  uint16_t values[MAX_PPM_CHANNELS];
  uint16_t crc;
};

static_assert(EEPROM_LOG_ADDRESS + sizeof(CaptureLogHeader) +
                      MAX_LOG_RECORDS * sizeof(CaptureLogRecord) <=
                  E2END + 1,
              "Capture log does not fit in ATmega328P EEPROM");

enum SteeringState : uint8_t {
  STEERING_LEFT = 0,
  STEERING_CENTER = 1,
  STEERING_RIGHT = 2,
};

enum ThrottleState : uint8_t {
  THROTTLE_REVERSE = 0,
  THROTTLE_NEUTRAL = 1,
  THROTTLE_FORWARD = 2,
};

// The full data set established that CH3 is a momentary command, not three
// steady mode values. Nine steering/throttle combinations are captured with
// CH3 released, followed by one centered/neutral sample with CH3 held down.
// The stock lighting board remembers and cycles ON / HAZARD / OFF internally.
constexpr uint8_t MATRIX_STATE_COUNT = 10;
constexpr uint16_t MATRIX_SETUP_TIME_MS = 5000;
constexpr uint16_t MATRIX_SAMPLE_TIME_MS = 2000;
constexpr uint16_t MATRIX_MAX_SPREAD_US = 150;
constexpr uint16_t MATRIX_FIELD_MATCH_TOLERANCE_US = 180;
constexpr uint16_t MODE_REQUIRED_CHANGE_US = 400;
constexpr uint8_t MATRIX_MIN_VALID_SAMPLES = 5;

const uint8_t MATRIX_STATES[MATRIX_STATE_COUNT][3] PROGMEM = {
    {STEERING_CENTER, THROTTLE_NEUTRAL, MODE_LINKAGE},
    {STEERING_LEFT, THROTTLE_FORWARD, MODE_LINKAGE},
    {STEERING_CENTER, THROTTLE_FORWARD, MODE_LINKAGE},
    {STEERING_RIGHT, THROTTLE_FORWARD, MODE_LINKAGE},
    {STEERING_LEFT, THROTTLE_NEUTRAL, MODE_LINKAGE},
    {STEERING_RIGHT, THROTTLE_NEUTRAL, MODE_LINKAGE},
    {STEERING_LEFT, THROTTLE_REVERSE, MODE_LINKAGE},
    {STEERING_CENTER, THROTTLE_REVERSE, MODE_LINKAGE},
    {STEERING_RIGHT, THROTTLE_REVERSE, MODE_LINKAGE},
    {STEERING_CENTER, THROTTLE_NEUTRAL, MODE_HAZARD},
};

const char *const STEERING_NAMES[] = {"LEFT", "CENTER", "RIGHT"};
const char *const THROTTLE_NAMES[] = {"REVERSE", "NEUTRAL", "FORWARD"};
const char *const MODE_NAMES[] = {"CH3_RELEASED", "CH3_PRESSED",
                                  "CH3_RELEASED_COPY"};

bool gMatrixActive = false;
uint8_t gMatrixStep = 0;
uint32_t gMatrixCaptureAtMs = 0;
bool gAutoScanActive = false;
PpmSample gAutoCandidate = {};
PpmSample gAutoAccepted = {};
uint8_t gAutoCandidateMatches = 0;
uint32_t gNextAutoCaptureMs = 0;

uint8_t levelAfterEdge(uint16_t index) {
  return (gLevelAfterBits[index >> 3] >> (index & 7)) & 0x01U;
}

void edgeIsr() {
  // Mirror the physical D4 logic level to D7 before doing any measurement.
  // Direct port access keeps the delay down to a handful of CPU cycles.
  bool outputHigh = (PIND & _BV(PD4)) != 0;
  if (PASSTHROUGH_INVERTS_INPUT) {
    outputHigh = !outputHigh;
  }
  if (outputHigh) {
    PORTD |= _BV(PD7);
  } else {
    PORTD &= static_cast<uint8_t>(~_BV(PD7));
  }

  if (!gCapturing) {
    return;
  }

  const uint32_t now = micros();
  const uint32_t elapsed = now - gLastEdgeUs;
  gLastEdgeUs = now;

  const uint16_t index = gEdgeCount;
  if (index >= MAX_EDGES) {
    return;
  }

  gDurationsUs[index] =
      elapsed > 65535UL ? 65535U : static_cast<uint16_t>(elapsed);
  if (PIND & _BV(PD4)) {
    gLevelAfterBits[index >> 3] |= static_cast<uint8_t>(1U << (index & 7));
  } else {
    gLevelAfterBits[index >> 3] &= static_cast<uint8_t>(~(1U << (index & 7)));
  }
  gEdgeCount = index + 1;
}

uint16_t captureEdges() {
  noInterrupts();
  gCapturing = false;
  gEdgeCount = 0;
  for (uint8_t i = 0; i < sizeof(gLevelAfterBits); ++i) {
    gLevelAfterBits[i] = 0;
  }
  gLastEdgeUs = micros();
  gCapturing = true;
  interrupts();

  delay(CAPTURE_TIME_MS);

  noInterrupts();
  gCapturing = false;
  const uint16_t count = gEdgeCount;
  interrupts();
  return count;
}

uint16_t median(uint16_t *values, uint8_t count) {
  for (uint8_t i = 1; i < count; ++i) {
    const uint16_t value = values[i];
    int8_t j = static_cast<int8_t>(i) - 1;
    while (j >= 0 && values[j] > value) {
      values[j + 1] = values[j];
      --j;
    }
    values[j + 1] = value;
  }
  return values[count / 2];
}

uint16_t difference(uint16_t a, uint16_t b) {
  return a >= b ? a - b : b - a;
}

uint16_t captureRecordCrc(const CaptureLogRecord &record) {
  const uint8_t *bytes = reinterpret_cast<const uint8_t *>(&record);
  uint16_t crc = 0xFFFFU;
  for (size_t i = 0; i < offsetof(CaptureLogRecord, crc); ++i) {
    crc = crc16Update(crc, bytes[i]);
  }
  return crc;
}

int captureRecordAddress(uint8_t index) {
  return EEPROM_LOG_ADDRESS + sizeof(CaptureLogHeader) +
         static_cast<int>(index) * sizeof(CaptureLogRecord);
}

bool captureLogHeaderValid(const CaptureLogHeader &header) {
  return header.magic == CAPTURE_LOG_MAGIC &&
         header.version == CAPTURE_LOG_VERSION &&
         header.count <= MAX_LOG_RECORDS;
}

void clearCaptureLog() {
  CaptureLogHeader header = {};
  header.magic = CAPTURE_LOG_MAGIC;
  header.version = CAPTURE_LOG_VERSION;
  header.count = 0;
  EEPROM.put(EEPROM_LOG_ADDRESS, header);
}

CaptureLogHeader readCaptureLogHeader() {
  CaptureLogHeader header = {};
  EEPROM.get(EEPROM_LOG_ADDRESS, header);
  if (!captureLogHeaderValid(header)) {
    clearCaptureLog();
    EEPROM.get(EEPROM_LOG_ADDRESS, header);
  }
  return header;
}

bool readCaptureRecord(uint8_t index, CaptureLogRecord &record) {
  const CaptureLogHeader header = readCaptureLogHeader();
  if (index >= header.count) {
    return false;
  }
  EEPROM.get(captureRecordAddress(index), record);
  return record.channelCount > 0 && record.channelCount <= MAX_PPM_CHANNELS &&
         record.crc == captureRecordCrc(record);
}

bool sampleMatchesRecord(const PpmSample &sample,
                         const CaptureLogRecord &record,
                         uint16_t toleranceUs) {
  if (!sample.valid || sample.channelCount != record.channelCount ||
      sample.protocol != record.protocol ||
      sample.activeHigh != ((record.flags & FLAG_PPM_ACTIVE_HIGH) != 0) ||
      difference(sample.frameUs, record.frameUs) > 150U ||
      difference(sample.pulseUs, record.pulseUs) > 120U) {
    return false;
  }
  for (uint8_t i = 0; i < sample.channelCount; ++i) {
    if (difference(sample.values[i], record.values[i]) > toleranceUs) {
      return false;
    }
  }
  return true;
}

bool samplesMatch(const PpmSample &a, const PpmSample &b,
                  uint16_t toleranceUs) {
  if (!a.valid || !b.valid || a.channelCount != b.channelCount ||
      a.protocol != b.protocol ||
      a.activeHigh != b.activeHigh ||
      difference(a.frameUs, b.frameUs) > 150U ||
      difference(a.pulseUs, b.pulseUs) > 120U) {
    return false;
  }
  for (uint8_t i = 0; i < a.channelCount; ++i) {
    if (difference(a.values[i], b.values[i]) > toleranceUs) {
      return false;
    }
  }
  return true;
}

void printRecordCsv(uint8_t index, const CaptureLogRecord &record) {
  Serial.print(index);
  Serial.print(',');
  Serial.print(record.kind == LOG_KIND_MATRIX ? F("MATRIX") : F("AUTO"));
  Serial.print(',');
  Serial.print(record.protocol == PROTOCOL_MJX_PULSE_FIELDS
                   ? F("MJX_PULSE_FIELDS")
                   : F("PPM_SUM"));
  Serial.print(',');
  if (record.steeringState < 3) {
    Serial.print(STEERING_NAMES[record.steeringState]);
  } else {
    Serial.print(F("UNKNOWN"));
  }
  Serial.print(',');
  if (record.throttleState < 3) {
    Serial.print(THROTTLE_NAMES[record.throttleState]);
  } else {
    Serial.print(F("UNKNOWN"));
  }
  Serial.print(',');
  if (record.modeState < 3) {
    Serial.print(MODE_NAMES[record.modeState]);
  } else {
    Serial.print(F("UNKNOWN"));
  }
  Serial.print(',');
  Serial.print((record.flags & FLAG_PPM_ACTIVE_HIGH) ? F("HIGH") : F("LOW"));
  Serial.print(',');
  Serial.print(record.channelCount);
  Serial.print(',');
  Serial.print(record.frameUs);
  Serial.print(',');
  Serial.print(record.pulseUs);
  for (uint8_t i = 0; i < MAX_PPM_CHANNELS; ++i) {
    Serial.print(',');
    if (i < record.channelCount) {
      Serial.print(record.values[i]);
    }
  }
  Serial.println();
}

void printCaptureLog() {
  const CaptureLogHeader header = readCaptureLogHeader();
  Serial.println(F("index,kind,protocol,steering,throttle,mode,active,channels,frame_or_sync_us,pulse_or_separator_us,ch0,ch1,ch2,ch3,ch4,ch5,ch6,ch7"));
  for (uint8_t i = 0; i < header.count; ++i) {
    CaptureLogRecord record = {};
    if (readCaptureRecord(i, record)) {
      printRecordCsv(i, record);
    } else {
      Serial.print(F("INVALID_RECORD,"));
      Serial.println(i);
    }
  }
  Serial.print(F("CAPTURE_LOG_COUNT="));
  Serial.println(header.count);
}

int8_t appendSampleToLog(const PpmSample &sample, uint8_t kind,
                         uint8_t steeringState, uint8_t throttleState,
                         uint8_t modeState, bool deduplicate,
                         bool &appendedOut) {
  appendedOut = false;
  if (!sample.valid) {
    return -1;
  }

  CaptureLogHeader header = readCaptureLogHeader();
  if (deduplicate) {
    for (uint8_t i = 0; i < header.count; ++i) {
      CaptureLogRecord existing = {};
      if (readCaptureRecord(i, existing) &&
          sampleMatchesRecord(sample, existing, STABLE_VALUE_TOLERANCE_US)) {
        return static_cast<int8_t>(i);
      }
    }
  }
  if (header.count >= MAX_LOG_RECORDS) {
    Serial.println(F("Capture log is full. Use 'dump', then 'clearlog'."));
    return -1;
  }

  CaptureLogRecord record = {};
  record.kind = kind;
  record.protocol = sample.protocol;
  record.steeringState = steeringState;
  record.throttleState = throttleState;
  record.modeState = modeState;
  record.flags = sample.activeHigh ? FLAG_PPM_ACTIVE_HIGH : 0;
  record.channelCount = sample.channelCount;
  record.frameUs = sample.frameUs;
  record.pulseUs = sample.pulseUs;
  for (uint8_t i = 0; i < sample.channelCount; ++i) {
    record.values[i] = sample.values[i];
  }
  record.crc = captureRecordCrc(record);

  const uint8_t index = header.count;
  EEPROM.put(captureRecordAddress(index), record);
  ++header.count;
  EEPROM.put(EEPROM_LOG_ADDRESS, header);
  appendedOut = true;
  return static_cast<int8_t>(index);
}

bool decodePpm(PpmSample &sample, uint16_t edgeCount) {
  sample = {};
  if (edgeCount < 12) {
    return false;
  }

  uint16_t narrowHighCount = 0;
  uint16_t narrowLowCount = 0;
  uint32_t narrowHighTotal = 0;
  uint32_t narrowLowTotal = 0;

  // Duration i belongs to the level before edge i. A real edge changes level,
  // so that previous level is the inverse of levelAfterEdge(i).
  for (uint16_t i = 1; i < edgeCount; ++i) {
    const uint16_t duration = gDurationsUs[i];
    if (duration < NARROW_MIN_US || duration > NARROW_MAX_US) {
      continue;
    }
    const bool previousWasHigh = !levelAfterEdge(i);
    if (previousWasHigh) {
      ++narrowHighCount;
      narrowHighTotal += duration;
    } else {
      ++narrowLowCount;
      narrowLowTotal += duration;
    }
  }

  if (narrowHighCount < 4 && narrowLowCount < 4) {
    return false;
  }
  const bool capturedActiveHigh = narrowHighCount >= narrowLowCount;
  const uint16_t narrowCount = capturedActiveHigh ? narrowHighCount : narrowLowCount;
  const uint32_t narrowTotal = capturedActiveHigh ? narrowHighTotal : narrowLowTotal;
  sample.pulseUs = static_cast<uint16_t>(narrowTotal / narrowCount);

  uint8_t pulseStartCount = 0;
  uint32_t relativeTimeUs = 0;
  for (uint16_t i = 0; i < edgeCount; ++i) {
    relativeTimeUs += gDurationsUs[i];
    if (levelAfterEdge(i) == capturedActiveHigh &&
        pulseStartCount < MAX_PULSE_STARTS) {
      gPulseStartsUs[pulseStartCount++] = relativeTimeUs;
    }
  }
  if (pulseStartCount < 6) {
    return false;
  }

  uint8_t channelCountVotes[MAX_PPM_CHANNELS + 1] = {};
  uint8_t previousMarker = 0xFF;
  for (uint8_t i = 1; i < pulseStartCount; ++i) {
    const uint32_t interval = gPulseStartsUs[i] - gPulseStartsUs[i - 1];
    if (interval <= SYNC_MIN_US) {
      continue;
    }
    if (previousMarker != 0xFF) {
      const uint8_t count = i - previousMarker - 1;
      if (count > 0 && count <= MAX_PPM_CHANNELS) {
        ++channelCountVotes[count];
      }
    }
    previousMarker = i;
  }

  uint8_t detectedChannels = 0;
  uint8_t bestVotes = 0;
  for (uint8_t count = 1; count <= MAX_PPM_CHANNELS; ++count) {
    if (channelCountVotes[count] > bestVotes) {
      bestVotes = channelCountVotes[count];
      detectedChannels = count;
    }
  }
  if (detectedChannels == 0 || bestVotes < 2) {
    return false;
  }

  uint8_t frameCount = 0;
  previousMarker = 0xFF;
  uint16_t frameLengths[MAX_CAPTURED_FRAMES] = {};
  for (uint8_t i = 1; i < pulseStartCount; ++i) {
    const uint32_t interval = gPulseStartsUs[i] - gPulseStartsUs[i - 1];
    if (interval <= SYNC_MIN_US) {
      continue;
    }
    if (previousMarker != 0xFF && frameCount < MAX_CAPTURED_FRAMES) {
      const uint8_t count = i - previousMarker - 1;
      if (count == detectedChannels) {
        bool frameValid = true;
        for (uint8_t channel = 0; channel < detectedChannels; ++channel) {
          const uint8_t startIndex = previousMarker + channel;
          const uint32_t width =
              gPulseStartsUs[startIndex + 1] - gPulseStartsUs[startIndex];
          if (width < 700UL || width > 2300UL) {
            frameValid = false;
            break;
          }
          gFrameValues[frameCount][channel] = static_cast<uint16_t>(width);
        }
        const uint32_t frameWidth =
            gPulseStartsUs[i] - gPulseStartsUs[previousMarker];
        if (frameWidth < 8000UL || frameWidth > 40000UL) {
          frameValid = false;
        }
        if (frameValid) {
          frameLengths[frameCount] = static_cast<uint16_t>(frameWidth);
          ++frameCount;
        }
      }
    }
    previousMarker = i;
  }

  if (frameCount < 2) {
    return false;
  }

  sample.channelCount = detectedChannels;
  sample.protocol = PROTOCOL_PPM_SUM;
  sample.frameUs = median(frameLengths, frameCount);
  sample.activeHigh = capturedActiveHigh ^ SIGNAL_CONDITIONER_INVERTS;
  for (uint8_t channel = 0; channel < detectedChannels; ++channel) {
    uint16_t column[MAX_CAPTURED_FRAMES];
    for (uint8_t frame = 0; frame < frameCount; ++frame) {
      column[frame] = gFrameValues[frame][channel];
    }
    sample.values[channel] = median(column, frameCount);
  }
  sample.valid = true;
  return true;
}

bool decodeMjxPulseFields(PpmSample &sample, uint16_t edgeCount) {
  sample = {};
  if (edgeCount < 16) {
    return false;
  }

  uint8_t longHighCount = 0;
  uint8_t longLowCount = 0;
  for (uint16_t i = 1; i < edgeCount; ++i) {
    if (gDurationsUs[i] < MJX_SYNC_MIN_US) {
      continue;
    }
    const bool previousHigh = !levelAfterEdge(i);
    if (previousHigh) {
      ++longHighCount;
    } else {
      ++longLowCount;
    }
  }
  if (longHighCount < 2 && longLowCount < 2) {
    return false;
  }

  const bool capturedSyncHigh = longHighCount > longLowCount;
  const bool capturedFieldHigh = !capturedSyncHigh;
  uint8_t channelCountVotes[MAX_PPM_CHANNELS + 1] = {};
  uint16_t previousMarker = 0xFFFFU;

  for (uint16_t i = 1; i < edgeCount; ++i) {
    const bool previousHigh = !levelAfterEdge(i);
    if (previousHigh != capturedSyncHigh ||
        gDurationsUs[i] < MJX_SYNC_MIN_US) {
      continue;
    }
    if (previousMarker != 0xFFFFU) {
      uint8_t fields = 0;
      for (uint16_t j = previousMarker + 1U; j < i; ++j) {
        const bool intervalHigh = !levelAfterEdge(j);
        const uint16_t width = gDurationsUs[j];
        if (intervalHigh == capturedFieldHigh &&
            width >= MJX_FIELD_MIN_US && width <= MJX_FIELD_MAX_US) {
          ++fields;
        }
      }
      if (fields > 0 && fields <= MAX_PPM_CHANNELS) {
        ++channelCountVotes[fields];
      }
    }
    previousMarker = i;
  }

  uint8_t detectedChannels = 0;
  uint8_t bestVotes = 0;
  for (uint8_t count = 1; count <= MAX_PPM_CHANNELS; ++count) {
    if (channelCountVotes[count] > bestVotes) {
      bestVotes = channelCountVotes[count];
      detectedChannels = count;
    }
  }
  if (detectedChannels == 0 || bestVotes < 2) {
    return false;
  }

  uint8_t frameCount = 0;
  uint16_t syncWidths[MAX_CAPTURED_FRAMES] = {};
  uint32_t separatorTotal = 0;
  uint16_t separatorCount = 0;
  previousMarker = 0xFFFFU;

  for (uint16_t i = 1; i < edgeCount; ++i) {
    const bool previousHigh = !levelAfterEdge(i);
    if (previousHigh != capturedSyncHigh ||
        gDurationsUs[i] < MJX_SYNC_MIN_US) {
      continue;
    }
    if (previousMarker != 0xFFFFU && frameCount < MAX_CAPTURED_FRAMES) {
      uint8_t fields = 0;
      for (uint16_t j = previousMarker + 1U; j < i; ++j) {
        const bool intervalHigh = !levelAfterEdge(j);
        const uint16_t width = gDurationsUs[j];
        if (intervalHigh == capturedFieldHigh &&
            width >= MJX_FIELD_MIN_US && width <= MJX_FIELD_MAX_US) {
          if (fields < detectedChannels) {
            gFrameValues[frameCount][fields] = width;
          }
          ++fields;
        } else if (intervalHigh == capturedSyncHigh &&
                   width >= MJX_SEPARATOR_MIN_US &&
                   width <= MJX_SEPARATOR_MAX_US) {
          separatorTotal += width;
          ++separatorCount;
        }
      }
      if (fields == detectedChannels) {
        syncWidths[frameCount] = gDurationsUs[previousMarker];
        ++frameCount;
      }
    }
    previousMarker = i;
  }

  if (frameCount < 2 || separatorCount == 0) {
    return false;
  }

  sample.protocol = PROTOCOL_MJX_PULSE_FIELDS;
  sample.activeHigh = capturedFieldHigh ^ SIGNAL_CONDITIONER_INVERTS;
  sample.channelCount = detectedChannels;
  sample.frameUs = median(syncWidths, frameCount);  // Long sync gap.
  sample.pulseUs = static_cast<uint16_t>(separatorTotal / separatorCount);
  for (uint8_t channel = 0; channel < detectedChannels; ++channel) {
    uint16_t column[MAX_CAPTURED_FRAMES];
    for (uint8_t frame = 0; frame < frameCount; ++frame) {
      column[frame] = gFrameValues[frame][channel];
    }
    sample.values[channel] = median(column, frameCount);
  }
  sample.valid = true;
  return true;
}

bool decodeSignal(PpmSample &sample, uint16_t edgeCount) {
  if (decodePpm(sample, edgeCount)) {
    return true;
  }
  return decodeMjxPulseFields(sample, edgeCount);
}

void printSample(const PpmSample &sample) {
  if (!sample.valid) {
    Serial.println(F("No supported repeatable frame decoded."));
    return;
  }
  Serial.print(sample.protocol == PROTOCOL_MJX_PULSE_FIELDS
                   ? F("MJX_PULSE_FIELDS active=")
                   : F("PPM_SUM active="));
  Serial.print(sample.activeHigh ? F("HIGH") : F("LOW"));
  Serial.print(F("  channels="));
  Serial.print(sample.channelCount);
  Serial.print(sample.protocol == PROTOCOL_MJX_PULSE_FIELDS
                   ? F("  sync_us=")
                   : F("  frame_us="));
  Serial.print(sample.frameUs);
  Serial.print(sample.protocol == PROTOCOL_MJX_PULSE_FIELDS
                   ? F("  separator_us=")
                   : F("  pulse_us="));
  Serial.print(sample.pulseUs);
  Serial.print(F("  values="));
  for (uint8_t i = 0; i < sample.channelCount; ++i) {
    if (i) {
      Serial.print(',');
    }
    Serial.print(sample.values[i]);
  }
  Serial.println();
}

void printRawCapture() {
  const uint16_t edgeCount = captureEdges();
  Serial.print(F("RAW edge_count="));
  Serial.println(edgeCount);
  Serial.println(F("index,duration_us,level_before,level_after"));
  for (uint16_t i = 1; i < edgeCount; ++i) {
    const uint8_t after = levelAfterEdge(i);
    Serial.print(i);
    Serial.print(',');
    Serial.print(gDurationsUs[i]);
    Serial.print(',');
    Serial.print(after ? 0 : 1);
    Serial.print(',');
    Serial.println(after);
  }
}

bool captureSample(PpmSample &sample) {
  Serial.println(F("Capturing for 220 ms..."));
  const uint16_t edgeCount = captureEdges();
  const bool decoded = decodeSignal(sample, edgeCount);
  printSample(sample);
  if (!decoded) {
    Serial.println(F("Use 'raw' and send the resulting CSV for protocol analysis."));
  }
  return decoded;
}

bool captureTwoSecondSample(PpmSample &stableSample) {
  uint32_t valueTotals[MAX_PPM_CHANNELS] = {};
  uint16_t valueMinimums[MAX_PPM_CHANNELS];
  uint16_t valueMaximums[MAX_PPM_CHANNELS] = {};
  uint32_t frameTotal = 0;
  uint32_t pulseTotal = 0;
  uint8_t validSamples = 0;
  uint8_t expectedProtocol = 0;
  uint8_t expectedChannels = 0;
  bool expectedActiveHigh = false;
  bool protocolMismatch = false;

  for (uint8_t i = 0; i < MAX_PPM_CHANNELS; ++i) {
    valueMinimums[i] = 0xFFFFU;
  }

  Serial.print(F("SAMPLING for 2 seconds"));
  const uint32_t startedMs = millis();
  while (static_cast<uint32_t>(millis() - startedMs) <
         MATRIX_SAMPLE_TIME_MS) {
    PpmSample current = {};
    Serial.print('.');
    if (!decodeSignal(current, captureEdges())) {
      continue;
    }

    if (validSamples == 0) {
      expectedProtocol = current.protocol;
      expectedChannels = current.channelCount;
      expectedActiveHigh = current.activeHigh;
    } else if (current.protocol != expectedProtocol ||
               current.channelCount != expectedChannels ||
               current.activeHigh != expectedActiveHigh) {
      protocolMismatch = true;
      continue;
    }

    ++validSamples;
    frameTotal += current.frameUs;
    pulseTotal += current.pulseUs;
    for (uint8_t channel = 0; channel < current.channelCount; ++channel) {
      const uint16_t value = current.values[channel];
      valueTotals[channel] += value;
      if (value < valueMinimums[channel]) {
        valueMinimums[channel] = value;
      }
      if (value > valueMaximums[channel]) {
        valueMaximums[channel] = value;
      }
    }
  }
  Serial.println();

  if (protocolMismatch || validSamples < MATRIX_MIN_VALID_SAMPLES) {
    Serial.print(F("UNSTABLE: valid samples="));
    Serial.print(validSamples);
    Serial.print(F(" required="));
    Serial.println(MATRIX_MIN_VALID_SAMPLES);
    return false;
  }

  stableSample = {};
  stableSample.valid = true;
  stableSample.protocol = expectedProtocol;
  stableSample.activeHigh = expectedActiveHigh;
  stableSample.channelCount = expectedChannels;
  stableSample.frameUs = static_cast<uint16_t>(frameTotal / validSamples);
  stableSample.pulseUs = static_cast<uint16_t>(pulseTotal / validSamples);
  for (uint8_t channel = 0; channel < expectedChannels; ++channel) {
    const uint16_t spread = valueMaximums[channel] - valueMinimums[channel];
    if (spread > MATRIX_MAX_SPREAD_US) {
      Serial.print(F("UNSTABLE: channel "));
      Serial.print(channel);
      Serial.print(F(" spread="));
      Serial.print(spread);
      Serial.println(F(" us"));
      stableSample.valid = false;
      return false;
    }
    stableSample.values[channel] =
        static_cast<uint16_t>(valueTotals[channel] / validSamples);
  }

  Serial.print(F("SOLID_VALUE samples="));
  Serial.println(validSamples);
  printSample(stableSample);
  return true;
}

void recordSnapshot(SnapshotId id) {
  PpmSample sample = {};
  if (captureSample(sample)) {
    gSnapshots[id] = sample;
    if (id == SNAP_BASE) {
      // Released CH3 is the normal idle value in every remembered light mode.
      gSnapshots[SNAP_OFF] = sample;
    }
    Serial.print(F("Recorded: "));
    Serial.println(SNAPSHOT_NAMES[id]);
  }
}

bool snapshotsCompatible() {
  if (!gSnapshots[SNAP_BASE].valid) {
    return false;
  }
  const PpmSample &base = gSnapshots[SNAP_BASE];
  for (uint8_t i = 0; i < SNAP_COUNT; ++i) {
    const PpmSample &sample = gSnapshots[i];
    if (!sample.valid || sample.channelCount != base.channelCount ||
        sample.protocol != base.protocol ||
        sample.activeHigh != base.activeHigh ||
        difference(sample.frameUs, base.frameUs) > 1500U ||
        difference(sample.pulseUs, base.pulseUs) > 150U) {
      return false;
    }
  }
  return true;
}

uint8_t largestChangedChannel(const PpmSample &a, const PpmSample &b,
                              const PpmSample &base, uint8_t excludedA,
                              uint8_t excludedB, uint16_t &scoreOut) {
  uint8_t bestChannel = 0xFF;
  uint16_t bestScore = 0;
  for (uint8_t channel = 0; channel < base.channelCount; ++channel) {
    if (channel == excludedA || channel == excludedB) {
      continue;
    }
    const uint16_t score = difference(a.values[channel], base.values[channel]) +
                           difference(b.values[channel], base.values[channel]);
    if (score > bestScore) {
      bestScore = score;
      bestChannel = channel;
    }
  }
  scoreOut = bestScore;
  return bestChannel;
}

bool inferCalibration(BridgeCalibration &calibration, bool printErrors) {
  if (!snapshotsCompatible()) {
    if (printErrors) {
      Serial.println(F("All seven compatible snapshots are required before save."));
    }
    return false;
  }

  const PpmSample &base = gSnapshots[SNAP_BASE];
  uint16_t steeringScore = 0;
  uint16_t throttleScore = 0;
  uint16_t modeScore = 0;

  const uint8_t steeringIndex = largestChangedChannel(
      gSnapshots[SNAP_LEFT], gSnapshots[SNAP_RIGHT], base, 0xFF, 0xFF,
      steeringScore);
  const uint8_t throttleIndex = largestChangedChannel(
      gSnapshots[SNAP_FORWARD], gSnapshots[SNAP_REVERSE], base,
      steeringIndex, 0xFF, throttleScore);
  const uint8_t modeIndex = largestChangedChannel(
      gSnapshots[SNAP_HAZARD], gSnapshots[SNAP_OFF], base, steeringIndex,
      throttleIndex, modeScore);

  if (steeringIndex == 0xFF || throttleIndex == 0xFF || modeIndex == 0xFF ||
      steeringScore < 150U || throttleScore < 150U || modeScore < 150U) {
    if (printErrors) {
      Serial.println(F("Could not distinguish steering/throttle/mode fields."));
      Serial.print(F("Change scores: steering="));
      Serial.print(steeringScore);
      Serial.print(F(" throttle="));
      Serial.print(throttleScore);
      Serial.print(F(" mode="));
      Serial.println(modeScore);
    }
    return false;
  }

  calibration = {};
  calibration.magic = CALIBRATION_MAGIC;
  calibration.version = CALIBRATION_VERSION;
  calibration.protocol = base.protocol;
  calibration.flags = base.activeHigh ? FLAG_PPM_ACTIVE_HIGH : 0;
  calibration.channelCount = base.channelCount;
  calibration.steeringIndex = steeringIndex;
  calibration.throttleIndex = throttleIndex;
  calibration.modeIndex = modeIndex;
  calibration.frameUs = base.frameUs;
  calibration.pulseUs = base.pulseUs;
  for (uint8_t i = 0; i < base.channelCount; ++i) {
    calibration.defaultValues[i] = base.values[i];
  }

  calibration.steeringUs[AXIS_LOW] =
      gSnapshots[SNAP_LEFT].values[steeringIndex];
  calibration.steeringUs[AXIS_CENTER] = base.values[steeringIndex];
  calibration.steeringUs[AXIS_HIGH] =
      gSnapshots[SNAP_RIGHT].values[steeringIndex];

  calibration.throttleUs[AXIS_LOW] =
      gSnapshots[SNAP_REVERSE].values[throttleIndex];
  calibration.throttleUs[AXIS_CENTER] = base.values[throttleIndex];
  calibration.throttleUs[AXIS_HIGH] =
      gSnapshots[SNAP_FORWARD].values[throttleIndex];

  calibration.modeUs[MODE_LINKAGE] = base.values[modeIndex];
  calibration.modeUs[MODE_HAZARD] =
      gSnapshots[SNAP_HAZARD].values[modeIndex];
  calibration.modeUs[MODE_OFF] = gSnapshots[SNAP_OFF].values[modeIndex];
  calibration.crc = calibrationCrc(calibration);
  return calibrationIsValid(calibration);
}

void printCalibration(const BridgeCalibration &calibration) {
  Serial.println(F("--- H12Y bridge calibration ---"));
  Serial.print(F("protocol="));
  Serial.println(calibration.protocol == PROTOCOL_MJX_PULSE_FIELDS
                     ? F("MJX_PULSE_FIELDS")
                     : F("PPM_SUM"));
  Serial.print(F("polarity="));
  Serial.println((calibration.flags & FLAG_PPM_ACTIVE_HIGH) ? F("ACTIVE_HIGH")
                                                           : F("ACTIVE_LOW"));
  Serial.print(F("channels="));
  Serial.print(calibration.channelCount);
  Serial.print(calibration.protocol == PROTOCOL_MJX_PULSE_FIELDS
                   ? F(" sync_us=")
                   : F(" frame_us="));
  Serial.print(calibration.frameUs);
  Serial.print(calibration.protocol == PROTOCOL_MJX_PULSE_FIELDS
                   ? F(" separator_us=")
                   : F(" pulse_us="));
  Serial.println(calibration.pulseUs);
  Serial.print(F("indices steering/throttle/mode="));
  Serial.print(calibration.steeringIndex);
  Serial.print('/');
  Serial.print(calibration.throttleIndex);
  Serial.print('/');
  Serial.println(calibration.modeIndex);
  Serial.print(F("steering left/center/right="));
  Serial.print(calibration.steeringUs[0]);
  Serial.print('/');
  Serial.print(calibration.steeringUs[1]);
  Serial.print('/');
  Serial.println(calibration.steeringUs[2]);
  Serial.print(F("throttle reverse/neutral/forward="));
  Serial.print(calibration.throttleUs[0]);
  Serial.print('/');
  Serial.print(calibration.throttleUs[1]);
  Serial.print('/');
  Serial.println(calibration.throttleUs[2]);
  Serial.print(F("CH3 released/pressed/released="));
  Serial.print(calibration.modeUs[0]);
  Serial.print('/');
  Serial.print(calibration.modeUs[1]);
  Serial.print('/');
  Serial.println(calibration.modeUs[2]);
}

void printSnapshotStatus() {
  Serial.println(F("Snapshot status:"));
  for (uint8_t i = 0; i < SNAP_COUNT; ++i) {
    Serial.print(F("  "));
    Serial.print(SNAPSHOT_NAMES[i]);
    Serial.print(F(": "));
    Serial.println(gSnapshots[i].valid ? F("recorded") : F("missing"));
  }
  BridgeCalibration inferred = {};
  if (inferCalibration(inferred, false)) {
    printCalibration(inferred);
  }
}

bool getMatrixState(uint8_t step, uint8_t &steering, uint8_t &throttle,
                    uint8_t &mode) {
  if (step >= MATRIX_STATE_COUNT) {
    return false;
  }
  steering = pgm_read_byte(&MATRIX_STATES[step][0]);
  throttle = pgm_read_byte(&MATRIX_STATES[step][1]);
  mode = pgm_read_byte(&MATRIX_STATES[step][2]);
  return true;
}

void saveAnchorSnapshot(uint8_t steering, uint8_t throttle, uint8_t mode,
                        const PpmSample &sample) {
  if (mode == MODE_LINKAGE && throttle == THROTTLE_NEUTRAL) {
    if (steering == STEERING_CENTER) {
      gSnapshots[SNAP_BASE] = sample;
      gSnapshots[SNAP_OFF] = sample;
    } else if (steering == STEERING_LEFT) {
      gSnapshots[SNAP_LEFT] = sample;
    } else if (steering == STEERING_RIGHT) {
      gSnapshots[SNAP_RIGHT] = sample;
    }
  }
  if (mode == MODE_LINKAGE && steering == STEERING_CENTER) {
    if (throttle == THROTTLE_FORWARD) {
      gSnapshots[SNAP_FORWARD] = sample;
    } else if (throttle == THROTTLE_REVERSE) {
      gSnapshots[SNAP_REVERSE] = sample;
    }
  }
  if (steering == STEERING_CENTER && throttle == THROTTLE_NEUTRAL) {
    if (mode == MODE_HAZARD) {
      gSnapshots[SNAP_HAZARD] = sample;
    } else if (mode == MODE_OFF) {
      gSnapshots[SNAP_OFF] = sample;
    }
  }
}

void printFriendlyStateName(uint8_t steering, uint8_t throttle, uint8_t mode) {
  if (mode == MODE_HAZARD) {
    Serial.print(F("CH3 BUTTON PRESSED"));
    return;
  }
  if (mode == MODE_OFF) {
    Serial.print(F("CH3 BUTTON RELEASED"));
    return;
  }

  if (throttle == THROTTLE_FORWARD) {
    Serial.print(F("FRONT "));
  } else if (throttle == THROTTLE_REVERSE) {
    Serial.print(F("REVERSE "));
  } else {
    Serial.print(F("NEUTRAL "));
  }

  if (steering == STEERING_LEFT) {
    Serial.print(F("LEFT"));
  } else if (steering == STEERING_RIGHT) {
    Serial.print(F("RIGHT"));
  } else {
    Serial.print(F("CENTER"));
  }
}

void printMatrixPrompt() {
  uint8_t steering;
  uint8_t throttle;
  uint8_t mode;
  if (!getMatrixState(gMatrixStep, steering, throttle, mode)) {
    return;
  }
  Serial.println();
  Serial.println();
  Serial.println();
  Serial.println(F("************************************************************"));
  Serial.println(F("************************************************************"));
  Serial.print(F("**                 MATRIX STEP "));
  Serial.print(gMatrixStep + 1);
  Serial.print('/');
  Serial.print(MATRIX_STATE_COUNT);
  Serial.println(F("                 **"));
  Serial.println(F("**                                                        **"));
  Serial.print(F("**  >>>  "));
  printFriendlyStateName(steering, throttle, mode);
  Serial.println(F("  <<<"));
  Serial.println(F("**                                                        **"));
  if (mode == MODE_HAZARD) {
    Serial.println(F("**  PRESS AND HOLD CH3 THROUGH THE ENTIRE SAMPLE          **"));
  } else if (mode == MODE_OFF) {
    Serial.println(F("**  RELEASE CH3                                            **"));
  } else if (gMatrixStep == 0) {
    Serial.println(F("**  ENSURE CH3 IS RELEASED                                 **"));
  } else {
    Serial.println(F("**  KEEP CH3 RELEASED                                      **"));
  }
  Serial.print(F("**  STEERING: "));
  Serial.println(STEERING_NAMES[steering]);
  Serial.print(F("**  THROTTLE: "));
  Serial.println(THROTTLE_NAMES[throttle]);
  Serial.println(F("**                                                        **"));
  Serial.println(F("**  SET IT NOW -- AUTOMATIC SAMPLING STARTS IN 5 SECONDS  **"));
  Serial.println(F("**  HOLD THE CONTROLS STEADY DURING THE 2-SECOND SAMPLE   **"));
  Serial.println(F("************************************************************"));
  Serial.println(F("************************************************************"));
  Serial.println();
  Serial.println();
  Serial.println();
  gMatrixCaptureAtMs = millis() + MATRIX_SETUP_TIME_MS;
}

bool validateMatrix(const BridgeCalibration &calibration) {
  const CaptureLogHeader header = readCaptureLogHeader();
  uint8_t matrixRecords = 0;
  uint8_t mismatchCount = 0;

  for (uint8_t index = 0; index < header.count; ++index) {
    CaptureLogRecord record = {};
    if (!readCaptureRecord(index, record) || record.kind != LOG_KIND_MATRIX) {
      continue;
    }
    ++matrixRecords;
    bool recordMatches =
        record.protocol == calibration.protocol &&
        record.channelCount == calibration.channelCount &&
        ((record.flags & FLAG_PPM_ACTIVE_HIGH) != 0) ==
            ((calibration.flags & FLAG_PPM_ACTIVE_HIGH) != 0) &&
        difference(record.frameUs, calibration.frameUs) <= 200U &&
        difference(record.pulseUs, calibration.pulseUs) <= 50U;

    for (uint8_t channel = 0;
         recordMatches && channel < calibration.channelCount; ++channel) {
      uint16_t expected = calibration.defaultValues[channel];
      if (channel == calibration.steeringIndex) {
        expected = calibration.steeringUs[record.steeringState];
      } else if (channel == calibration.throttleIndex) {
        expected = calibration.throttleUs[record.throttleState];
      } else if (channel == calibration.modeIndex) {
        expected = calibration.modeUs[record.modeState];
      }
      if (difference(record.values[channel], expected) >
          MATRIX_FIELD_MATCH_TOLERANCE_US) {
        recordMatches = false;
        Serial.print(F("Matrix mismatch record="));
        Serial.print(index);
        Serial.print(F(" channel="));
        Serial.print(channel);
        Serial.print(F(" actual="));
        Serial.print(record.values[channel]);
        Serial.print(F(" expected="));
        Serial.println(expected);
      }
    }
    if (!recordMatches) {
      ++mismatchCount;
    }
  }

  if (matrixRecords != MATRIX_STATE_COUNT) {
    Serial.print(F("Expected "));
    Serial.print(MATRIX_STATE_COUNT);
    Serial.print(F(" matrix records; found "));
    Serial.println(matrixRecords);
    return false;
  }
  if (mismatchCount) {
    Serial.print(F("Matrix records with mismatches: "));
    Serial.println(mismatchCount);
    return false;
  }
  Serial.println(F("All drive combinations plus CH3 released/pressed are consistent."));
  return true;
}

void finishMatrix() {
  gMatrixActive = false;
  // There is no distinct steady OFF field. Released CH3 is used before and
  // after every button gesture; the lighting board stores the visible mode.
  if (gSnapshots[SNAP_BASE].valid) {
    gSnapshots[SNAP_OFF] = gSnapshots[SNAP_BASE];
  }
  BridgeCalibration calibration = {};
  Serial.println();
  Serial.print(F("All "));
  Serial.print(MATRIX_STATE_COUNT);
  Serial.println(F(" states captured. Inferring and validating..."));
  const bool inferred = inferCalibration(calibration, true);
  const bool validMatrix = inferred && validateMatrix(calibration);
  printCaptureLog();
  if (validMatrix) {
    saveCalibration(calibration);
    Serial.println(F("MATRIX_OK: calibration automatically saved to EEPROM."));
    printCalibration(calibration);
  } else {
    Serial.println(F("MATRIX_FAILED: calibration was not saved."));
    Serial.println(F("Copy the complete CSV above and send it for analysis."));
  }
}

bool modeSampleIsDistinct(uint8_t requestedMode, const PpmSample &sample) {
  if (requestedMode != MODE_HAZARD) {
    return true;
  }

  const PpmSample &base = gSnapshots[SNAP_BASE];
  if (!base.valid || !gSnapshots[SNAP_LEFT].valid ||
      !gSnapshots[SNAP_RIGHT].valid || !gSnapshots[SNAP_FORWARD].valid ||
      !gSnapshots[SNAP_REVERSE].valid ||
      sample.channelCount != base.channelCount) {
    Serial.println(F("MODE CHECK FAILED: required linkage anchors are missing."));
    return false;
  }

  uint16_t ignoredScore;
  const uint8_t steeringIndex = largestChangedChannel(
      gSnapshots[SNAP_LEFT], gSnapshots[SNAP_RIGHT], base, 0xFF, 0xFF,
      ignoredScore);
  const uint8_t throttleIndex = largestChangedChannel(
      gSnapshots[SNAP_FORWARD], gSnapshots[SNAP_REVERSE], base,
      steeringIndex, 0xFF, ignoredScore);

  uint8_t modeIndex = 0xFF;
  uint16_t greatestModeChange = 0;
  for (uint8_t channel = 0; channel < base.channelCount; ++channel) {
    if (channel == steeringIndex || channel == throttleIndex) {
      continue;
    }
    const uint16_t change =
        difference(sample.values[channel], base.values[channel]);
    if (modeIndex == 0xFF || change > greatestModeChange) {
      modeIndex = channel;
      greatestModeChange = change;
    }
  }

  if (modeIndex == 0xFF ||
      difference(sample.values[modeIndex], base.values[modeIndex]) <
          MODE_REQUIRED_CHANGE_US) {
    Serial.println();
    Serial.println(F("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    Serial.println(F("!!  CH3 STILL LOOKS RELEASED                              !!"));
    Serial.println(F("!!  HOLD CH3 DOWN THROUGH THE ENTIRE SAMPLE              !!"));
    Serial.println(F("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    Serial.println();
    return false;
  }

  return true;
}

void captureCurrentMatrixStep() {
  if (!gMatrixActive) {
    Serial.println(F("No matrix session is active. Type 'matrix' first."));
    return;
  }

  uint8_t steering;
  uint8_t throttle;
  uint8_t mode;
  if (!getMatrixState(gMatrixStep, steering, throttle, mode)) {
    finishMatrix();
    return;
  }

  PpmSample stable = {};
  if (!captureTwoSecondSample(stable)) {
    Serial.println(F("This step was not appended; it will retry automatically."));
    printMatrixPrompt();
    return;
  }

  if (!modeSampleIsDistinct(mode, stable)) {
    printMatrixPrompt();
    return;
  }

  bool appended = false;
  const int8_t index = appendSampleToLog(
      stable, LOG_KIND_MATRIX, steering, throttle, mode, false, appended);
  if (index < 0 || !appended) {
    Serial.println(F("Could not append matrix record; session stopped."));
    gMatrixActive = false;
    return;
  }
  saveAnchorSnapshot(steering, throttle, mode, stable);

  CaptureLogRecord record = {};
  if (readCaptureRecord(static_cast<uint8_t>(index), record)) {
    Serial.println(F("APPENDED_MATRIX_ROW:"));
    Serial.println(F("index,kind,protocol,steering,throttle,mode,active,channels,frame_or_sync_us,pulse_or_separator_us,ch0,ch1,ch2,ch3,ch4,ch5,ch6,ch7"));
    printRecordCsv(static_cast<uint8_t>(index), record);
  }

  ++gMatrixStep;
  if (gMatrixStep >= MATRIX_STATE_COUNT) {
    finishMatrix();
  } else {
    printMatrixPrompt();
  }
}

void processMatrix() {
  if (!gMatrixActive ||
      static_cast<int32_t>(millis() - gMatrixCaptureAtMs) < 0) {
    return;
  }
  captureCurrentMatrixStep();
}

void startMatrix() {
  gAutoScanActive = false;
  gMatrixActive = true;
  gMatrixStep = 0;
  eraseCalibration();
  clearCaptureLog();
  for (uint8_t i = 0; i < SNAP_COUNT; ++i) {
    gSnapshots[i] = {};
  }
  Serial.print(F("10-state automatic matrix started; old log and calibration invalidated."));
  Serial.println();
  Serial.println(F("Keep the vehicle safely supported during throttle steps."));
  Serial.println(F("No further commands are needed; follow each REQUEST prompt."));
  printMatrixPrompt();
}

bool sampleFromLogRecord(const CaptureLogRecord &record, PpmSample &sample) {
  if (record.kind != LOG_KIND_MATRIX || record.channelCount == 0 ||
      record.channelCount > MAX_PPM_CHANNELS) {
    return false;
  }
  sample = {};
  sample.valid = true;
  sample.protocol = record.protocol;
  sample.activeHigh = (record.flags & FLAG_PPM_ACTIVE_HIGH) != 0;
  sample.channelCount = record.channelCount;
  sample.frameUs = record.frameUs;
  sample.pulseUs = record.pulseUs;
  for (uint8_t i = 0; i < record.channelCount; ++i) {
    sample.values[i] = record.values[i];
  }
  return true;
}

void resumeMatrix() {
  const CaptureLogHeader header = readCaptureLogHeader();
  if (header.count == 0 || header.count > MATRIX_STATE_COUNT) {
    Serial.println(F("RESUME FAILED: capture log must contain 1 to 10 rows."));
    return;
  }

  for (uint8_t i = 0; i < SNAP_COUNT; ++i) {
    gSnapshots[i] = {};
  }
  for (uint8_t index = 0; index < header.count; ++index) {
    CaptureLogRecord record = {};
    PpmSample sample = {};
    uint8_t expectedSteering;
    uint8_t expectedThrottle;
    uint8_t expectedMode;
    if (!readCaptureRecord(index, record) ||
        !getMatrixState(index, expectedSteering, expectedThrottle,
                        expectedMode) ||
        record.steeringState != expectedSteering ||
        record.throttleState != expectedThrottle ||
        record.modeState != expectedMode ||
        !sampleFromLogRecord(record, sample)) {
      Serial.print(F("RESUME FAILED: invalid or unexpected row "));
      Serial.println(index);
      return;
    }
    saveAnchorSnapshot(record.steeringState, record.throttleState,
                       record.modeState, sample);
  }

  gAutoScanActive = false;
  gMatrixStep = header.count;
  gMatrixActive = true;
  if (gMatrixStep == MATRIX_STATE_COUNT) {
    Serial.println(F("Existing 10-row capture is complete; validating it now."));
    finishMatrix();
    return;
  }
  Serial.print(F("RESUMED_MATRIX_AT_STEP="));
  Serial.println(gMatrixStep + 1);
  printMatrixPrompt();
}

void processAutoScan() {
  if (!gAutoScanActive || gMatrixActive ||
      static_cast<int32_t>(millis() - gNextAutoCaptureMs) < 0) {
    return;
  }
  gNextAutoCaptureMs = millis() + 60UL;

  PpmSample current = {};
  if (!decodeSignal(current, captureEdges())) {
    gAutoCandidate.valid = false;
    gAutoCandidateMatches = 0;
    return;
  }
  if (samplesMatch(current, gAutoAccepted, STABLE_VALUE_TOLERANCE_US)) {
    return;
  }

  if (samplesMatch(current, gAutoCandidate, STABLE_VALUE_TOLERANCE_US)) {
    if (gAutoCandidateMatches < 255) {
      ++gAutoCandidateMatches;
    }
  } else {
    gAutoCandidate = current;
    gAutoCandidateMatches = 1;
  }

  if (gAutoCandidateMatches < 2) {
    return;
  }

  bool appended = false;
  const int8_t index = appendSampleToLog(
      current, LOG_KIND_AUTO, STATE_UNKNOWN, STATE_UNKNOWN, STATE_UNKNOWN, true,
      appended);
  gAutoAccepted = current;
  gAutoCandidateMatches = 0;

  if (index < 0) {
    gAutoScanActive = false;
    return;
  }
  if (appended) {
    Serial.print(F("AUTO_STABLE_APPENDED index="));
    Serial.println(index);
    if (AUTO_DUMP_AFTER_APPEND) {
      printCaptureLog();
    }
  }
}

void printHelp() {
  Serial.println();
  Serial.println(F("H12Y CH3 learner commands"));
  Serial.println(F("  matrix   - automatic 10-state, two-second capture run"));
  Serial.println(F("  resume   - continue an interrupted matrix from EEPROM"));
  Serial.println(F("  stop     - stop an active matrix or automatic scan"));
  Serial.println(F("  auto     - toggle automatic stable-value logging"));
  Serial.println(F("  dump     - print every EEPROM capture row as CSV"));
  Serial.println(F("  clearlog - erase the capture-row log (not calibration)"));
  Serial.println(F("  sample   - decode and print the present signal"));
  Serial.println(F("  raw      - print a raw edge-duration CSV"));
  Serial.println(F("  base     - CENTER steering, NEUTRAL throttle, CH3 released"));
  Serial.println(F("  left     - full steering LEFT; other controls at base"));
  Serial.println(F("  right    - full steering RIGHT; other controls at base"));
  Serial.println(F("  forward  - full FORWARD; steering centered, CH3 released"));
  Serial.println(F("  reverse  - full REVERSE; steering centered, CH3 released"));
  Serial.println(F("  button   - CH3 held; steering centered, throttle neutral"));
  Serial.println(F("  hazard   - compatibility alias for 'button'"));
  Serial.println(F("  off      - optional second copy with CH3 released"));
  Serial.println(F("  show     - show capture status and inferred calibration"));
  Serial.println(F("  save     - infer calibration and save it to EEPROM"));
  Serial.println(F("  saved    - display calibration currently in EEPROM"));
  Serial.println(F("  erase    - invalidate the saved EEPROM calibration"));
  Serial.println(F("  help     - show this list"));
  Serial.println();
}

void handleCommand(const char *command) {
  if (!strcmp(command, "matrix")) {
    startMatrix();
  } else if (!strcmp(command, "resume")) {
    if (gMatrixActive || gAutoScanActive) {
      Serial.println(F("Stop the active capture session before resuming."));
    } else {
      resumeMatrix();
    }
  } else if (!strcmp(command, "stop")) {
    gMatrixActive = false;
    gAutoScanActive = false;
    Serial.println(F("Active capture session stopped."));
  } else if (!strcmp(command, "auto")) {
    if (gMatrixActive) {
      Serial.println(F("Stop the matrix session before starting auto scan."));
    } else {
      gAutoScanActive = !gAutoScanActive;
      gAutoCandidate = {};
      gAutoAccepted = {};
      gAutoCandidateMatches = 0;
      gNextAutoCaptureMs = millis();
      Serial.println(gAutoScanActive
                         ? F("AUTO_SCAN_ON: hold each position until appended.")
                         : F("AUTO_SCAN_OFF"));
    }
  } else if (!strcmp(command, "dump")) {
    printCaptureLog();
  } else if (!strcmp(command, "clearlog")) {
    if (gMatrixActive || gAutoScanActive) {
      Serial.println(F("Stop the active capture session before clearing."));
    } else {
      clearCaptureLog();
      Serial.println(F("Capture log cleared; bridge calibration was retained."));
    }
  } else if (!strcmp(command, "sample")) {
    PpmSample sample = {};
    captureSample(sample);
  } else if (!strcmp(command, "raw")) {
    printRawCapture();
  } else if (!strcmp(command, "base")) {
    recordSnapshot(SNAP_BASE);
  } else if (!strcmp(command, "left")) {
    recordSnapshot(SNAP_LEFT);
  } else if (!strcmp(command, "right")) {
    recordSnapshot(SNAP_RIGHT);
  } else if (!strcmp(command, "forward")) {
    recordSnapshot(SNAP_FORWARD);
  } else if (!strcmp(command, "reverse")) {
    recordSnapshot(SNAP_REVERSE);
  } else if (!strcmp(command, "button") || !strcmp(command, "hazard")) {
    recordSnapshot(SNAP_HAZARD);
  } else if (!strcmp(command, "off")) {
    recordSnapshot(SNAP_OFF);
  } else if (!strcmp(command, "show")) {
    printSnapshotStatus();
  } else if (!strcmp(command, "save")) {
    BridgeCalibration calibration = {};
    if (inferCalibration(calibration, true)) {
      saveCalibration(calibration);
      Serial.println(F("Calibration saved to EEPROM."));
      printCalibration(calibration);
    }
  } else if (!strcmp(command, "saved")) {
    BridgeCalibration calibration = {};
    if (loadCalibration(calibration)) {
      printCalibration(calibration);
    } else {
      Serial.println(F("No valid calibration is stored in EEPROM."));
    }
  } else if (!strcmp(command, "erase")) {
    eraseCalibration();
    Serial.println(F("EEPROM calibration invalidated."));
  } else if (!strcmp(command, "help") || !strcmp(command, "?")) {
    printHelp();
  } else if (command[0] != '\0') {
    Serial.print(F("Unknown command: "));
    Serial.println(command);
  }
}

void readSerialCommands() {
  while (Serial.available()) {
    const char c = static_cast<char>(Serial.read());
    if (c == '\r') {
      continue;
    }
    if (c == '\n') {
      gCommand[gCommandLength] = '\0';
      handleCommand(gCommand);
      gCommandLength = 0;
    } else if (gCommandLength < sizeof(gCommand) - 1U) {
      if (c >= 'A' && c <= 'Z') {
        gCommand[gCommandLength++] = c - 'A' + 'a';
      } else {
        gCommand[gCommandLength++] = c;
      }
    }
  }
}

}  // namespace

void setup() {
  pinMode(SIGNAL_PIN, INPUT);
  bool initialOutputHigh = digitalRead(SIGNAL_PIN) == HIGH;
  if (PASSTHROUGH_INVERTS_INPUT) {
    initialOutputHigh = !initialOutputHigh;
  }
  digitalWrite(PASSTHROUGH_PIN, initialOutputHigh ? HIGH : LOW);
  pinMode(PASSTHROUGH_PIN, OUTPUT);
  Serial.begin(115200);
  const uint32_t waitStarted = millis();
  while (!Serial && millis() - waitStarted < 3000UL) {
  }

  noInterrupts();
  PCIFR |= _BV(PCIF2);     // Clear any pending Port-D pin-change interrupt.
  PCMSK2 |= _BV(PCINT20);  // Enable Nano D4 / PD4 only.
  PCICR |= _BV(PCIE2);     // Enable the Port-D pin-change interrupt group.
  interrupts();
  Serial.println(F("MJX H12Y CH3 protocol learner + D7 passthrough ready."));
  Serial.println(F("D4 receiver input is being mirrored continuously to D7."));
  printHelp();
}

void loop() {
  readSerialCommands();
  processMatrix();
  processAutoScan();
}

ISR(PCINT2_vect) {
  edgeIsr();
}
