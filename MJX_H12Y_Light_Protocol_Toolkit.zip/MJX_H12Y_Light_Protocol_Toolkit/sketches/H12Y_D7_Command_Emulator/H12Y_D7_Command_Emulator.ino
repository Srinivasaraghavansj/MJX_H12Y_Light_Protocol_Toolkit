/*
  MJX H12Y stock lighting-board command emulator
  Target: classic Arduino Nano / ATmega328P

  Wiring:
    Nano D7  -> stock lighting-board signal input
    Nano GND -> stock lighting-board ground

  D4 is intentionally unused by this sketch. Disconnect the receiver signal
  from the lighting board before driving the board from D7. Never connect two
  push-pull outputs together.

  Learned MJX frame, active HIGH:
    LOW sync, HIGH CH3 field, LOW separator, HIGH throttle field,
    LOW separator, HIGH steering field, then LOW sync again.

  CH3 is a momentary button command. The lighting board remembers and cycles
  its own ON / HAZARD / OFF state. A steady third "OFF pulse" does not exist.
*/

#include <Arduino.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <string.h>

#if !defined(__AVR_ATmega328P__)
#error "Select a classic ATmega328P Arduino Nano board."
#endif

namespace {

constexpr uint8_t OUTPUT_PIN = 7;  // Nano D7 = PD7.

// Exact values from the final MATRIX_OK calibration.
constexpr uint16_t SYNC_US = 12154;
constexpr uint16_t SEPARATOR_US = 1027;
constexpr uint16_t CH3_RELEASED_US = 6104;
constexpr uint16_t CH3_PRESSED_US = 5110;

constexpr uint16_t THROTTLE_REVERSE_US = 2063;
constexpr uint16_t THROTTLE_NEUTRAL_US = 3027;
constexpr uint16_t THROTTLE_FORWARD_US = 4071;

constexpr uint16_t STEERING_LEFT_US = 2036;
constexpr uint16_t STEERING_CENTER_US = 3026;
constexpr uint16_t STEERING_RIGHT_US = 4069;

constexpr uint16_t CH3_GESTURE_MS = 350;
constexpr uint16_t MODE_GESTURE_GAP_MS = 500;
constexpr uint16_t DEMO_STEP_MS = 2500;
constexpr uint16_t MODE_DEMO_GAP_MS = 3500;
constexpr uint16_t RAW_MIN_US = 500;
constexpr uint16_t RAW_MAX_US = 12000;

enum SteeringPosition : uint8_t {
  STEER_LEFT = 0,
  STEER_CENTER = 1,
  STEER_RIGHT = 2,
};

enum ThrottlePosition : uint8_t {
  THROTTLE_REVERSE = 0,
  THROTTLE_NEUTRAL = 1,
  THROTTLE_FORWARD = 2,
};

enum EncoderPhase : uint8_t {
  PHASE_SYNC = 0,
  PHASE_FIELD_0,
  PHASE_SEPARATOR_0,
  PHASE_FIELD_1,
  PHASE_SEPARATOR_1,
  PHASE_FIELD_2,
};

enum TestMode : uint8_t {
  TEST_NONE = 0,
  TEST_DRIVE_COMBINATIONS,
  TEST_MODE_GESTURES,
  TEST_ALL,
  TEST_BRAKE,
};

// With no press at power-up the board starts ON. Each completed press advances
// ON -> HAZARD -> OFF -> ON.
enum TrackedLightMode : uint8_t {
  LIGHT_MODE_ON = 0,
  LIGHT_MODE_HAZARD = 1,
  LIGHT_MODE_OFF = 2,
};

const uint16_t STEERING_VALUES[] = {
    STEERING_LEFT_US, STEERING_CENTER_US, STEERING_RIGHT_US};
const uint16_t THROTTLE_VALUES[] = {
    THROTTLE_REVERSE_US, THROTTLE_NEUTRAL_US, THROTTLE_FORWARD_US};
const char *const STEERING_NAMES[] = {"LEFT", "CENTER", "RIGHT"};
const char *const THROTTLE_NAMES[] = {"REVERSE", "NEUTRAL", "FORWARD"};
const char *const LIGHT_MODE_NAMES[] = {"ON", "HAZARD", "OFF"};

// Same order as the successful learner matrix.
const uint8_t DRIVE_DEMO[][2] = {
    {STEER_CENTER, THROTTLE_NEUTRAL},
    {STEER_LEFT, THROTTLE_FORWARD},
    {STEER_CENTER, THROTTLE_FORWARD},
    {STEER_RIGHT, THROTTLE_FORWARD},
    {STEER_LEFT, THROTTLE_NEUTRAL},
    {STEER_RIGHT, THROTTLE_NEUTRAL},
    {STEER_LEFT, THROTTLE_REVERSE},
    {STEER_CENTER, THROTTLE_REVERSE},
    {STEER_RIGHT, THROTTLE_REVERSE},
};
constexpr uint8_t DRIVE_DEMO_COUNT = sizeof(DRIVE_DEMO) / sizeof(DRIVE_DEMO[0]);

volatile uint16_t gNextFields[3] = {
    CH3_RELEASED_US, THROTTLE_NEUTRAL_US, STEERING_CENTER_US};
volatile uint16_t gActiveFields[3] = {
    CH3_RELEASED_US, THROTTLE_NEUTRAL_US, STEERING_CENTER_US};
volatile bool gFieldsPending = false;
volatile EncoderPhase gEncoderPhase = PHASE_SYNC;

SteeringPosition gSteering = STEER_CENTER;
ThrottlePosition gThrottle = THROTTLE_NEUTRAL;
bool gCh3Active = false;
bool gCh3TimedGesture = false;
uint32_t gCh3ReleaseAtMs = 0;
bool gRawOverride = false;

TestMode gTestMode = TEST_NONE;
uint8_t gTestStep = 0;
uint32_t gNextTestStepMs = 0;
bool gContinueToModesAfterBrake = false;

TrackedLightMode gTrackedLightMode = LIGHT_MODE_ON;
TrackedLightMode gRequestedLightMode = LIGHT_MODE_ON;
uint8_t gQueuedModeGestures = 0;
uint32_t gNextModeGestureMs = 0;
bool gModeRequestActive = false;

char gCommand[64];
uint8_t gCommandLength = 0;

inline void setOutputHigh(bool high) {
  if (high) {
    PORTD |= _BV(PD7);
  } else {
    PORTD &= static_cast<uint8_t>(~_BV(PD7));
  }
}

inline uint16_t timerTicksForUs(uint16_t durationUs) {
  // 16 MHz / Timer1 prescaler 8 = 2 ticks per microsecond.
  uint32_t ticks = static_cast<uint32_t>(durationUs) * 2UL;
  if (ticks < 2UL) {
    ticks = 2UL;
  } else if (ticks > 65535UL) {
    ticks = 65535UL;
  }
  return static_cast<uint16_t>(ticks - 1UL);
}

void queueFields(uint16_t ch3Us, uint16_t throttleUs, uint16_t steeringUs) {
  noInterrupts();
  gNextFields[0] = ch3Us;
  gNextFields[1] = throttleUs;
  gNextFields[2] = steeringUs;
  gFieldsPending = true;
  interrupts();
}

void applyKnownState() {
  gRawOverride = false;
  queueFields(gCh3Active ? CH3_PRESSED_US : CH3_RELEASED_US,
              THROTTLE_VALUES[gThrottle], STEERING_VALUES[gSteering]);
}

void advanceTrackedLightMode() {
  if (gTrackedLightMode == LIGHT_MODE_ON) {
    gTrackedLightMode = LIGHT_MODE_HAZARD;
  } else if (gTrackedLightMode == LIGHT_MODE_HAZARD) {
    gTrackedLightMode = LIGHT_MODE_OFF;
  } else {
    gTrackedLightMode = LIGHT_MODE_ON;
  }
  Serial.print(F("TRACKED_LIGHT_MODE="));
  Serial.println(LIGHT_MODE_NAMES[gTrackedLightMode]);
}

void cancelModeRequest() {
  gQueuedModeGestures = 0;
  gModeRequestActive = false;
}

void printState() {
  uint16_t fields[3];
  noInterrupts();
  for (uint8_t i = 0; i < 3; ++i) {
    fields[i] = gNextFields[i];
  }
  interrupts();

  Serial.print(F("OUTPUT D7: ch0/ch1/ch2="));
  Serial.print(fields[0]);
  Serial.print('/');
  Serial.print(fields[1]);
  Serial.print('/');
  Serial.print(fields[2]);
  Serial.print(F(" us"));
  if (!gRawOverride) {
    Serial.print(F("  CH3="));
    Serial.print(gCh3Active ? F("PRESSED") : F("RELEASED"));
    Serial.print(F("  THROTTLE="));
    Serial.print(THROTTLE_NAMES[gThrottle]);
    Serial.print(F("  STEERING="));
    Serial.print(STEERING_NAMES[gSteering]);
    Serial.print(F("  LIGHT_MODE="));
    Serial.print(LIGHT_MODE_NAMES[gTrackedLightMode]);
  } else {
    Serial.print(F("  RAW_OVERRIDE"));
  }
  Serial.println();
}

void setDriveState(SteeringPosition steering, ThrottlePosition throttle,
                   bool announce) {
  gSteering = steering;
  gThrottle = throttle;
  applyKnownState();
  if (announce) {
    printState();
  }
}

void releaseCh3(bool announce) {
  gCh3TimedGesture = false;
  gCh3Active = false;
  applyKnownState();
  if (announce) {
    Serial.println(F("CH3 RELEASED"));
    printState();
  }
}

void holdCh3() {
  gCh3TimedGesture = false;
  gCh3Active = true;
  applyKnownState();
  Serial.println(F("CH3 HELD: type 'release' to release it."));
  printState();
}

void startCh3Gesture() {
  gCh3Active = true;
  gCh3TimedGesture = true;
  gCh3ReleaseAtMs = millis() + CH3_GESTURE_MS;
  applyKnownState();
  Serial.print(F("CH3 PRESS GESTURE: "));
  Serial.print(CH3_GESTURE_MS);
  Serial.println(F(" ms, then automatic release."));
}

void processCh3Gesture() {
  if (gCh3TimedGesture &&
      static_cast<int32_t>(millis() - gCh3ReleaseAtMs) >= 0) {
    releaseCh3(false);
    advanceTrackedLightMode();
    Serial.println(F("CH3 GESTURE COMPLETE; output returned to RELEASED."));
    if (gModeRequestActive && gQueuedModeGestures == 0) {
      gModeRequestActive = false;
      Serial.print(F("REQUESTED MODE REACHED: "));
      Serial.println(LIGHT_MODE_NAMES[gTrackedLightMode]);
    }
  }
}

uint8_t gesturesToReach(TrackedLightMode target) {
  return static_cast<uint8_t>((static_cast<uint8_t>(target) + 3U -
                               static_cast<uint8_t>(gTrackedLightMode)) %
                              3U);
}

void requestLightMode(TrackedLightMode target) {
  gRequestedLightMode = target;
  gQueuedModeGestures = gesturesToReach(target);
  gModeRequestActive = gQueuedModeGestures != 0;
  gNextModeGestureMs = millis();

  if (!gModeRequestActive) {
    Serial.print(F("LIGHT MODE ALREADY "));
    Serial.println(LIGHT_MODE_NAMES[target]);
    return;
  }

  Serial.print(F("REQUESTING LIGHT MODE "));
  Serial.print(LIGHT_MODE_NAMES[target]);
  Serial.print(F(" using "));
  Serial.print(gQueuedModeGestures);
  Serial.println(F(" CH3 gesture(s)."));
}

void processModeRequest() {
  if (!gModeRequestActive || gCh3TimedGesture ||
      static_cast<int32_t>(millis() - gNextModeGestureMs) < 0) {
    return;
  }

  if (gQueuedModeGestures == 0) {
    gModeRequestActive = false;
    return;
  }

  --gQueuedModeGestures;
  startCh3Gesture();
  gNextModeGestureMs =
      millis() + CH3_GESTURE_MS + MODE_GESTURE_GAP_MS;
}

void printDemoStep(uint8_t step) {
  Serial.println();
  Serial.println(F("************************************************************"));
  Serial.print(F("** DRIVE TEST "));
  Serial.print(step + 1);
  Serial.print('/');
  Serial.print(DRIVE_DEMO_COUNT);
  Serial.print(F(": "));
  Serial.print(THROTTLE_NAMES[gThrottle]);
  Serial.print(' ');
  Serial.print(STEERING_NAMES[gSteering]);
  Serial.println(F(" **"));
  Serial.println(F("************************************************************"));
  printState();
}

void startDriveTest(TestMode mode) {
  releaseCh3(false);
  gContinueToModesAfterBrake = false;
  gTestMode = mode;
  gTestStep = 0;
  gNextTestStepMs = millis();
  Serial.println(F("AUTOMATIC DRIVE-COMBINATION TEST STARTED."));
}

void startModeTest(TestMode mode) {
  cancelModeRequest();
  releaseCh3(false);
  setDriveState(STEER_CENTER, THROTTLE_NEUTRAL, false);
  gTestMode = mode;
  gTestStep = 0;
  gNextTestStepMs = millis() + 1500UL;
  Serial.println();
  Serial.println(F("CH3 MODE-CYCLE TEST: watch the stock board after each gesture."));
  Serial.println(F("The board, not the Nano, remembers ON / HAZARD / OFF."));
}

void stopTest(bool announce) {
  cancelModeRequest();
  gTestMode = TEST_NONE;
  gTestStep = 0;
  gContinueToModesAfterBrake = false;
  releaseCh3(false);
  setDriveState(STEER_CENTER, THROTTLE_NEUTRAL, false);
  if (announce) {
    Serial.println(F("AUTOMATIC TEST STOPPED; CENTER / NEUTRAL / CH3 RELEASED."));
  }
}

void startBrakeTest() {
  releaseCh3(false);
  gContinueToModesAfterBrake = false;
  gTestMode = TEST_BRAKE;
  gTestStep = 0;
  gNextTestStepMs = millis();
  Serial.println(F("BRAKE TEST: FORWARD will be followed by NEUTRAL."));
}

void processAutomaticTest() {
  if (gTestMode == TEST_NONE ||
      static_cast<int32_t>(millis() - gNextTestStepMs) < 0) {
    return;
  }

  if (gTestMode == TEST_DRIVE_COMBINATIONS || gTestMode == TEST_ALL) {
    if (gTestStep < DRIVE_DEMO_COUNT) {
      const uint8_t steering = DRIVE_DEMO[gTestStep][0];
      const uint8_t throttle = DRIVE_DEMO[gTestStep][1];
      setDriveState(static_cast<SteeringPosition>(steering),
                    static_cast<ThrottlePosition>(throttle), false);
      printDemoStep(gTestStep);
      ++gTestStep;
      gNextTestStepMs = millis() + DEMO_STEP_MS;
      return;
    }

    if (gTestMode == TEST_ALL) {
      releaseCh3(false);
      gContinueToModesAfterBrake = true;
      gTestMode = TEST_BRAKE;
      gTestStep = 0;
      gNextTestStepMs = millis();
      Serial.println(F("ALL TEST: continuing with the brake transition."));
    } else {
      stopTest(false);
      Serial.println(F("DRIVE-COMBINATION TEST COMPLETE."));
    }
    return;
  }

  if (gTestMode == TEST_MODE_GESTURES) {
    if (gTestStep < 3) {
      Serial.println();
      Serial.print(F("CH3 CYCLE GESTURE "));
      Serial.print(gTestStep + 1);
      Serial.println(F("/3"));
      startCh3Gesture();
      ++gTestStep;
      gNextTestStepMs = millis() + MODE_DEMO_GAP_MS;
    } else {
      stopTest(false);
      Serial.println(F("CH3 MODE-CYCLE TEST COMPLETE."));
    }
    return;
  }

  if (gTestMode == TEST_BRAKE) {
    if (gTestStep == 0) {
      setDriveState(STEER_CENTER, THROTTLE_FORWARD, true);
      Serial.println(F("BRAKE TEST PHASE 1: FORWARD"));
      gTestStep = 1;
      gNextTestStepMs = millis() + 1500UL;
    } else if (gTestStep == 1) {
      setDriveState(STEER_CENTER, THROTTLE_NEUTRAL, true);
      Serial.println(F("BRAKE TEST PHASE 2: NEUTRAL -- watch brake lights."));
      gTestStep = 2;
      gNextTestStepMs = millis() + 3000UL;
    } else {
      if (gContinueToModesAfterBrake) {
        gContinueToModesAfterBrake = false;
        Serial.println(F("BRAKE TEST COMPLETE; continuing with CH3 gestures."));
        startModeTest(TEST_MODE_GESTURES);
      } else {
        stopTest(false);
        Serial.println(F("BRAKE TEST COMPLETE."));
      }
    }
  }
}

void cancelAutomaticTestForManualCommand() {
  if (gTestMode != TEST_NONE) {
    gTestMode = TEST_NONE;
    gContinueToModesAfterBrake = false;
    Serial.println(F("Automatic test cancelled by manual command."));
  }
}

bool parseRawCommand(const char *command) {
  if (strncmp(command, "raw ", 4) != 0) {
    return false;
  }

  char *end = nullptr;
  const unsigned long ch0 = strtoul(command + 4, &end, 10);
  if (end == command + 4) {
    return false;
  }
  const unsigned long ch1 = strtoul(end, &end, 10);
  const unsigned long ch2 = strtoul(end, &end, 10);
  if (ch0 < RAW_MIN_US || ch0 > RAW_MAX_US || ch1 < RAW_MIN_US ||
      ch1 > RAW_MAX_US || ch2 < RAW_MIN_US || ch2 > RAW_MAX_US) {
    Serial.println(F("RAW REJECTED: each value must be 500..12000 us."));
    return true;
  }

  cancelAutomaticTestForManualCommand();
  cancelModeRequest();
  gCh3TimedGesture = false;
  gRawOverride = true;
  queueFields(static_cast<uint16_t>(ch0), static_cast<uint16_t>(ch1),
              static_cast<uint16_t>(ch2));
  printState();
  return true;
}

bool parseDrivePhrase(const char *command) {
  char copy[sizeof(gCommand)];
  strncpy(copy, command, sizeof(copy) - 1U);
  copy[sizeof(copy) - 1U] = '\0';

  int8_t requestedSteering = -1;
  int8_t requestedThrottle = -1;
  bool recognizedAny = false;
  bool conflict = false;

  char *save = nullptr;
  for (char *token = strtok_r(copy, " ", &save); token != nullptr;
       token = strtok_r(nullptr, " ", &save)) {
    int8_t steering = -1;
    int8_t throttle = -1;

    if (!strcmp(token, "left")) {
      steering = STEER_LEFT;
    } else if (!strcmp(token, "right")) {
      steering = STEER_RIGHT;
    } else if (!strcmp(token, "straight") || !strcmp(token, "center") ||
               !strcmp(token, "centre")) {
      steering = STEER_CENTER;
    } else if (!strcmp(token, "forward") || !strcmp(token, "front")) {
      throttle = THROTTLE_FORWARD;
    } else if (!strcmp(token, "backward") || !strcmp(token, "backwards") ||
               !strcmp(token, "back") || !strcmp(token, "reverse")) {
      throttle = THROTTLE_REVERSE;
    } else if (!strcmp(token, "neutral") || !strcmp(token, "stationary")) {
      throttle = THROTTLE_NEUTRAL;
    } else {
      return false;
    }

    recognizedAny = true;
    if (steering >= 0) {
      if (requestedSteering >= 0 && requestedSteering != steering) {
        conflict = true;
      }
      requestedSteering = steering;
    }
    if (throttle >= 0) {
      if (requestedThrottle >= 0 && requestedThrottle != throttle) {
        conflict = true;
      }
      requestedThrottle = throttle;
    }
  }

  if (!recognizedAny) {
    return false;
  }
  if (conflict) {
    Serial.println(F("COMMAND REJECTED: conflicting directions."));
    return true;
  }

  cancelAutomaticTestForManualCommand();
  const SteeringPosition steering =
      requestedSteering >= 0
          ? static_cast<SteeringPosition>(requestedSteering)
          : gSteering;
  const ThrottlePosition throttle =
      requestedThrottle >= 0
          ? static_cast<ThrottlePosition>(requestedThrottle)
          : gThrottle;
  setDriveState(steering, throttle, true);
  return true;
}

void printHelp() {
  Serial.println();
  Serial.println(F("H12Y D7 command emulator"));
  Serial.println(F("  left / straight / right - set steering-light field"));
  Serial.println(F("  backward / neutral / forward - set throttle-light field"));
  Serial.println(F("  forward left, backward right, etc. - atomic combination"));
  Serial.println(F("  press    - one 350 ms CH3 press then release"));
  Serial.println(F("  on / off / hazard - reach a tracked lighting mode"));
  Serial.println(F("  hold     - hold CH3 active until 'release'"));
  Serial.println(F("  release  - release CH3"));
  Serial.println(F("  combos   - automatically show all 9 drive combinations"));
  Serial.println(F("  modes    - perform 3 spaced CH3 gestures"));
  Serial.println(F("  brake    - forward-to-neutral brake-light test"));
  Serial.println(F("  all      - combinations, brake test, then CH3 gestures"));
  Serial.println(F("  raw A B C - directly set ch0/ch1/ch2 widths in us"));
  Serial.println(F("  status   - show current D7 fields"));
  Serial.println(F("  stop     - stop a test and return to safe neutral"));
  Serial.println(F("  help     - show this list"));
  Serial.println();
}

void handleCommand(const char *command) {
  if (parseRawCommand(command)) {
    return;
  }
  if (!strcmp(command, "help") || !strcmp(command, "?")) {
    printHelp();
    return;
  }
  if (!strcmp(command, "status")) {
    printState();
    return;
  }
  if (!strcmp(command, "stop")) {
    stopTest(true);
    return;
  }
  if (!strcmp(command, "combos")) {
    startDriveTest(TEST_DRIVE_COMBINATIONS);
    return;
  }
  if (!strcmp(command, "modes")) {
    startModeTest(TEST_MODE_GESTURES);
    return;
  }
  if (!strcmp(command, "all")) {
    startDriveTest(TEST_ALL);
    return;
  }
  if (!strcmp(command, "brake")) {
    startBrakeTest();
    return;
  }
  if (!strcmp(command, "on") || !strcmp(command, "lights on")) {
    cancelAutomaticTestForManualCommand();
    cancelModeRequest();
    requestLightMode(LIGHT_MODE_ON);
    return;
  }
  if (!strcmp(command, "off") || !strcmp(command, "lights off")) {
    cancelAutomaticTestForManualCommand();
    cancelModeRequest();
    requestLightMode(LIGHT_MODE_OFF);
    return;
  }
  if (!strcmp(command, "hazard") || !strcmp(command, "hazards")) {
    cancelAutomaticTestForManualCommand();
    cancelModeRequest();
    requestLightMode(LIGHT_MODE_HAZARD);
    return;
  }
  if (!strcmp(command, "cycle") || !strcmp(command, "press")) {
    cancelAutomaticTestForManualCommand();
    cancelModeRequest();
    startCh3Gesture();
  } else if (!strcmp(command, "hold")) {
    cancelAutomaticTestForManualCommand();
    cancelModeRequest();
    holdCh3();
  } else if (!strcmp(command, "release")) {
    cancelAutomaticTestForManualCommand();
    cancelModeRequest();
    const bool completedPress = gCh3Active;
    releaseCh3(true);
    if (completedPress) {
      advanceTrackedLightMode();
    }
  } else if (parseDrivePhrase(command)) {
    return;
  } else if (command[0] != '\0') {
    Serial.print(F("Unknown command: "));
    Serial.println(command);
  }
}

void readSerialCommands() {
  while (Serial.available()) {
    const char c = static_cast<char>(Serial.read());
    if (c == '\r') {
      continue;
    }
    if (c == '\n') {
      gCommand[gCommandLength] = '\0';
      handleCommand(gCommand);
      gCommandLength = 0;
    } else if (gCommandLength < sizeof(gCommand) - 1U) {
      gCommand[gCommandLength++] =
          (c >= 'A' && c <= 'Z') ? static_cast<char>(c - 'A' + 'a') : c;
    }
  }
}

void beginEncoder() {
  digitalWrite(OUTPUT_PIN, LOW);
  pinMode(OUTPUT_PIN, OUTPUT);

  noInterrupts();
  gEncoderPhase = PHASE_SYNC;
  TCCR1A = 0;
  TCCR1B = _BV(WGM12) | _BV(CS11);  // CTC mode, prescaler 8.
  TCNT1 = 0;
  OCR1A = timerTicksForUs(SYNC_US);
  TIMSK1 |= _BV(OCIE1A);
  interrupts();
}

}  // namespace

ISR(TIMER1_COMPA_vect) {
  switch (gEncoderPhase) {
    case PHASE_SYNC:
      if (gFieldsPending) {
        for (uint8_t i = 0; i < 3; ++i) {
          gActiveFields[i] = gNextFields[i];
        }
        gFieldsPending = false;
      }
      setOutputHigh(true);
      gEncoderPhase = PHASE_FIELD_0;
      OCR1A = timerTicksForUs(gActiveFields[0]);
      break;

    case PHASE_FIELD_0:
      setOutputHigh(false);
      gEncoderPhase = PHASE_SEPARATOR_0;
      OCR1A = timerTicksForUs(SEPARATOR_US);
      break;

    case PHASE_SEPARATOR_0:
      setOutputHigh(true);
      gEncoderPhase = PHASE_FIELD_1;
      OCR1A = timerTicksForUs(gActiveFields[1]);
      break;

    case PHASE_FIELD_1:
      setOutputHigh(false);
      gEncoderPhase = PHASE_SEPARATOR_1;
      OCR1A = timerTicksForUs(SEPARATOR_US);
      break;

    case PHASE_SEPARATOR_1:
      setOutputHigh(true);
      gEncoderPhase = PHASE_FIELD_2;
      OCR1A = timerTicksForUs(gActiveFields[2]);
      break;

    case PHASE_FIELD_2:
    default:
      setOutputHigh(false);
      gEncoderPhase = PHASE_SYNC;
      OCR1A = timerTicksForUs(SYNC_US);
      break;
  }
}

void setup() {
  beginEncoder();
  Serial.begin(115200);
  const uint32_t waitStarted = millis();
  while (!Serial && millis() - waitStarted < 3000UL) {
  }

  Serial.println();
  Serial.println(F("MJX H12Y D7 command emulator ready."));
  Serial.println(F("Safe startup: CENTER / NEUTRAL / CH3 RELEASED."));
  Serial.println(F("No automatic CH3 presses; stock lights remain ON by default."));
  printState();
  printHelp();
}

void loop() {
  readSerialCommands();
  processCh3Gesture();
  processModeRequest();
  processAutomaticTest();
}
